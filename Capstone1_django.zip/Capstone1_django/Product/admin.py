from django.contrib import admin

from Product.models import Survey, Contact, Survey_44, Survey_49, Survey_51

admin.site.register(Survey)
admin.site.register(Survey_44)
admin.site.register(Survey_49)
admin.site.register(Survey_51)
admin.site.register(Contact)
# @admin.register(Survey)
# class SurveyAdmin(admin.ModelAdmin):
#     list_display = ('education', 'province')
#     fieldsets = (
#         ('Address', {
#             'fields': ('province', 'district', 'ward')
#         }),
#         ('General Info', {
#             'fields': ('education', 'gender')
#         }),
#     )
#
