import logging

from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render
from django.views import View

from django.contrib.auth import authenticate, login, decorators, logout
from django.contrib.auth.mixins import LoginRequiredMixin
from .constant import *
from .models import Survey, Contact, Survey_44, Survey_49, Survey_51
from django.shortcuts import redirect
import logging
import numpy as np

_logger = logging.getLogger(__name__)
import sys

# libraries
import matplotlib.pyplot as plt
import pandas as pd
import io
import base64


# Create your views here.

class HomeView(View):
    def get(self, request):
        return render(request, 'homepage/index.html')


class ContactView(View):
    def get(self, request):
        return render(request, 'homepage/contact.html')


#
# class LoadDataView(View):
#     def get(self, request):
#         ## call database, get du lieu
#         ## data
#         data = null
#         return render(request, 'homepage/contact.html',data)

class FormView(View):
    def get(self, request):
        context = {
            "education": EDUCATION,
            "area": AREA,
            "gender": GENDER,
            "nation": NATION,
            "age": AGE,
            "children": CHILDREN,
            "children_education": EDUCATIONCHILDREN,
            "distance": DISTANCE,
            "people": PEOPLE,
            "income": INCOME,
            "decision": DECISION,
            "confidence": CONFIDENCE,
            "own": OWN,
            "loanamount": LoanAmount,
            "selectdecide": SelectDecide,
            "join": Join,
            "positivity": POSITIVITY,
            "work": WORK,
            "workof": WORKOF,
        }
        return render(request, 'homepage/form.html', context)


class ResultView(View):
    def get(self, request):
        return render(request, 'homepage/result.html')

class ResultChartsView(View):
    def get(self, request, namechart):
        data = Survey.objects.all()
        if namechart == 'charts-44':
            data = Survey_44.objects.all()
            print('44')
        else:
            data = Survey_51.objects.all()
            print('51')
        # data
        index2 = [1, 2]
        index3 = [1, 2, 3]
        index4 = [1, 2, 3, 4]
        index5 = [1, 2, 3, 4, 5]
        index6 = [1, 2, 3, 4, 5, 6]
        index7 = [1, 2, 3, 4, 5, 6, 7]
        index8 = [1, 2, 3, 4, 5, 6, 7, 8]
        for item in data:
            item.area = converttonumber(item.area, index4, 'area')
            item.nation = converttonumber(item.nation, index2, 'nation')
            item.gender = converttonumber(item.gender, index3, 'gender')
            item.age = converttonumber(item.age, index5, 'age')
            item.education = converttonumber(item.education, index7, 'education')
            item.children = converttonumber(item.children, index7, 'children')
            item.children_education = converttonumber(item.children_education, index8, 'children_education')
            item.distance = converttonumber(item.distance, index7, 'distance')
            item.people = converttonumber(item.people, index7, 'people')
            item.income = converttonumber(item.income, index5, 'income')
            item.footcrops1 = converttonumber(item.footcrops1, index5, 'footcrops1')
            item.footcrops2 = converttonumber(item.footcrops2, index5, 'footcrops2')
            item.treecommercial1 = converttonumber(item.treecommercial1, index5, 'treecommercial1')
            item.treecommercial2 = converttonumber(item.treecommercial2, index5, 'treecommercial2')
            item.breed1 = converttonumber(item.breed1, index5, 'breed1')
            item.breed2 = converttonumber(item.breed2, index5, 'breed2')
            item.employed1 = converttonumber(item.employed1, index5, 'employed1')
            item.employed2 = converttonumber(item.employed2, index5, 'employed2')
            item.spending1 = converttonumber(item.spending1, index5, 'spending1')
            item.spending2 = converttonumber(item.spending2, index5, 'spending2')
            item.ordinaryspending1 = converttonumber(item.ordinaryspending1, index5, 'ordinaryspending1')
            item.ordinaryspending2 = converttonumber(item.ordinaryspending2, index5, 'ordinaryspending2')
            item.agriculturalland1 = converttonumber(item.agriculturalland1, index5, 'agriculturalland1')
            item.agriculturalland2 = converttonumber(item.agriculturalland2, index5, 'agriculturalland2')
            item.bigpets1 = converttonumber(item.bigpets1, index5, 'bigpets1')
            item.bigpets2 = converttonumber(item.bigpets2, index5, 'bigpets2')
            item.average1 = converttonumber(item.average1, index5, 'average1')
            item.average2 = converttonumber(item.average2, index5, 'average2')
            item.smallpets1 = converttonumber(item.smallpets1, index5, 'smallpets1')
            item.smallpets2 = converttonumber(item.smallpets2, index5, 'smallpets2')
            item.fishpond1 = converttonumber(item.fishpond1, index5, 'fishpond1')
            item.fishpond2 = converttonumber(item.fishpond2, index5, 'fishpond2')
            item.agriculturaltools1 = converttonumber(item.agriculturaltools1, index5, 'agriculturaltools1')
            item.agriculturaltools2 = converttonumber(item.agriculturaltools2, index5, 'agriculturaltools2')
            item.machines1 = converttonumber(item.machines1, index5, 'machines1')
            item.machines2 = converttonumber(item.machines2, index5, 'machines2')
            # llllllllll
            item.device1 = converttonumber(item.device1, index5, 'device1')
            item.device2 = converttonumber(item.device2, index5, 'device2')
            item.home1 = converttonumber(item.home1, index5, 'home1')
            item.home2 = converttonumber(item.home2, index5, 'home2')
            item.belongings1 = converttonumber(item.belongings1, index5, 'belongings1')
            item.belongings2 = converttonumber(item.belongings2, index5, 'belongings2')
            item.smallbelongings1 = converttonumber(item.smallbelongings1, index5, 'smallbelongings1')
            item.smallbelongings2 = converttonumber(item.smallbelongings2, index5, 'smallbelongings2')
            item.phone1 = converttonumber(item.phone1, index5, 'phone1')
            item.phone2 = converttonumber(item.phone2, index5, 'phone2')
            item.nonagricultural1 = converttonumber(item.nonagricultural1, index5, 'nonagricultural1')
            item.nonagricultural2 = converttonumber(item.nonagricultural2, index5, 'nonagricultural2')
            item.vehicle1 = converttonumber(item.vehicle1, index5, 'vehicle1')
            item.vehicle2 = converttonumber(item.vehicle2, index5, 'vehicle2')
            # # llllll
            item.nongovernmental1 = converttonumber(item.nongovernmental1, index5, 'nongovernmental1')
            item.nongovernmental2 = converttonumber(item.nongovernmental2, index5, 'nongovernmental2')
            item.official1 = converttonumber(item.official1, index5, 'official1')
            item.official2 = converttonumber(item.official2, index5, 'official2')
            item.friend1 = converttonumber(item.friend1, index5, 'friend1')
            item.friend2 = converttonumber(item.friend2, index5, 'friend2')
            item.spendingfamily = converttonumber(item.spendingfamily, index5, 'spendingfamily')
            # # ppppppppp4
            item.trade1 = converttonumber(item.trade1, index5, 'trade1')
            item.trade2 = converttonumber(item.trade2, index6, 'trade2')
            item.forestry1 = converttonumber(item.forestry1, index5, 'forestry1')
            item.forestry2 = converttonumber(item.forestry2, index6, 'forestry2')
            item.finance1 = converttonumber(item.finance1, index5, 'finance1')
            item.finance2 = converttonumber(item.finance2, index6, 'finance2')
            item.insurance1 = converttonumber(item.insurance1, index5, 'insurance1')
            item.insurance2 = converttonumber(item.insurance2, index6, 'insurance2')
            item.business1 = converttonumber(item.business1, index5, 'business1')
            item.business2 = converttonumber(item.business2, index6, 'business2')
            item.charity1 = converttonumber(item.charity1, index5, 'charity1')
            item.charity2 = converttonumber(item.charity2, index6, 'charity2')
            item.religion1 = converttonumber(item.religion1, index5, 'religion1')
            item.religion2 = converttonumber(item.religion2, index6, 'religion2')
            item.work = converttonumber(item.work, index5, 'work')
            item.workof = converttonumber(item.workof, index5, 'workof')

        export_data = []
        id = 0
        for item in data:
            temp = []
            temp.append(id)
            id = id + 1
            tbsx = round((item.footcrops1 + item.treecommercial1 + item.breed1 + item.employed1 + item.footcrops2 + \
                          item.treecommercial2 + item.breed2 + item.employed2) / 8, 3)
            temp.append(tbsx)
            tbnl = round(
                (item.machines1 + item.agriculturalland1 + item.bigpets1 + item.agriculturaltools1 + item.home1
                 + item.nonagricultural1 + item.machines2 + item.agriculturalland2 + item.bigpets2
                 + item.agriculturaltools2 + item.home2 + item.nonagricultural2 + item.official1
                 + item.nongovernmental1 + item.friend1) / 15, 3)
            temp.append(tbnl)
            tngd = item.income
            temp.append(tngd)
            tbtgxh = round((item.insurance1 + item.forestry1 + item.charity1 + item.insurance2 + item.forestry2
                            + item.charity2) / 6, 3)
            temp.append(tbtgxh)
            tbsdtg = round((item.work + item.workof) / 2, 3)
            temp.append(tbsdtg)
            tbtqcc = round((tbsx + tbnl * 0.5 + tngd * 2 + tbtgxh + tbsdtg) / 5, 3)
            temp.append(tbtqcc)
            tbtqccX2 = round(tbtqcc * 2, 3)
            temp.append(tbtqccX2)
            traoquyen = 0
            if (tbtqccX2 / 10 > 0.6):
                traoquyen = 1
            else:
                traoquyen = 0
            temp.append(traoquyen)
            export_data.append(temp)

        #clear
        plt.clf()

        plt.rcParams["figure.figsize"] = (20, 5)
        # create random data
        names = 'Không trao quyền', 'Được trao quyền'
        values = [0, 0]
        for item in export_data:
            if item[8] == 0:
                values[0]=values[0]+1
            elif item[8] == 1:
                values[1] = values[1] + 1
        # Create a pieplot
        plt.pie(values,labels=names,autopct='%.2f');

        flike = io.BytesIO()
        plt.savefig(flike)
        b64 = base64.b64encode(flike.getvalue()).decode()

        context = {
            'namechart': namechart,
            'charts': b64
        }

        return render(request, 'homepage/result-chart.html', context)

class LoginView(View):
    def get(self, request):
        return render(request, 'homepage/index-login.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        my_user = authenticate(username=username, password=password)
        if my_user is None:
            return HttpResponse('user không tồn tại')
        login(request, my_user)
        return render(request, 'homepage/index-dashboard.html')

class LogoutView(View):
    def get(self, request):
        logout(request)

        # return render(request, 'homepage/index-login.html')
        return redirect('/login-views/')

class DashBoardView(LoginRequiredMixin, View):
    login_url = '/login-views/'

    def get(self, request):
        return render(request, 'homepage/index-dashboard.html')

    def post(self, request):
        pass
    # def get(self, request):
    #     if not request.user.is_authenticated:
    #     # if request.user.id != None:
    #         return render(request, 'homepage/index-dashboard.html')
    #     else:
    #         return redirect('/login-views/')


def getName(key, constant):
    if constant == 'area':
        data = AREA
    if constant == 'nation':
        data = NATION
    if constant == 'gender':
        data = GENDER
    if constant == 'age':
        data = AGE
    if constant == 'education':
        data = EDUCATION
    if constant == 'children':
        data = CHILDREN
    if constant == 'children_education':
        data = EDUCATIONCHILDREN
    if constant == 'distance':
        data = DISTANCE
    if constant == 'people':
        data = PEOPLE
    if constant == 'income':
        data = INCOME
    if constant == 'footcrops1':
        data = DECISION
    if constant == 'footcrops2':
        data = CONFIDENCE
    if constant == 'treecommercial1':
        data = DECISION
    if constant == 'treecommercial2':
        data = CONFIDENCE
    if constant == 'breed1':
        data = DECISION
    if constant == 'breed2':
        data = CONFIDENCE
    if constant == 'employed1':
        data = DECISION
    if constant == 'employed2':
        data = CONFIDENCE
    if constant == 'spending1':
        data = DECISION
    if constant == 'spending2':
        data = CONFIDENCE
    if constant == 'ordinaryspending1':
        data = DECISION
    if constant == 'ordinaryspending2':
        data = CONFIDENCE
    if constant == 'agriculturalland1':
        data = OWN
    if constant == 'agriculturalland2':
        data = DECISION
    if constant == 'bigpets1':
        data = OWN
    if constant == 'bigpets2':
        data = DECISION
    if constant == 'average1':
        data = OWN
    if constant == 'average2':
        data = DECISION
    if constant == 'smallpets1':
        data = OWN
    if constant == 'smallpets2':
        data = DECISION
    if constant == 'fishpond1':
        data = OWN
    if constant == 'fishpond2':
        data = DECISION
    if constant == 'agriculturaltools1':
        data = OWN
    if constant == 'agriculturaltools2':
        data = DECISION
    if constant == 'machines1':
        data = OWN
    if constant == 'machines2':
        data = DECISION
    # lllllllllllll
    if constant == 'device1':
        data = OWN
    if constant == 'device2':
        data = DECISION
    if constant == 'home1':
        data = OWN
    if constant == 'home2':
        data = DECISION
    if constant == 'belongings1':
        data = OWN
    if constant == 'belongings2':
        data = DECISION
    if constant == 'smallbelongings1':
        data = OWN
    if constant == 'smallbelongings2':
        data = DECISION
    if constant == 'phone1':
        data = OWN
    if constant == 'phone2':
        data = DECISION
    if constant == 'nonagricultural1':
        data = OWN
    if constant == 'nonagricultural2':
        data = DECISION
    if constant == 'vehicle1':
        data = OWN
    if constant == 'vehicle2':
        data = DECISION
    # llllll
    if constant == 'nongovernmental1':
        data = LoanAmount
    if constant == 'nongovernmental2':
        data = SelectDecide
    if constant == 'official1':
        data = LoanAmount
    if constant == 'official2':
        data = SelectDecide
    if constant == 'friend1':
        data = LoanAmount
    if constant == 'friend2':
        data = SelectDecide
    if constant == 'spendingfamily':
        data = SelectDecide
    # ppppppppppp4
    if constant == 'trade1':
        data = Join
    if constant == 'trade2':
        data = POSITIVITY
    if constant == 'forestry1':
        data = Join
    if constant == 'forestry2':
        data = POSITIVITY
    if constant == 'finance1':
        data = Join
    if constant == 'finance2':
        data = POSITIVITY
    if constant == 'insurance1':
        data = Join
    if constant == 'insurance2':
        data = POSITIVITY
    if constant == 'business1':
        data = Join
    if constant == 'business2':
        data = POSITIVITY
    if constant == 'charity1':
        data = Join
    if constant == 'charity2':
        data = POSITIVITY
    if constant == 'religion1':
        data = Join
    if constant == 'religion2':
        data = POSITIVITY
    if constant == 'work':
        data = WORK
    if constant == 'workof':
        data = WORKOF
    for item in data:
        if item[0] == key:
            return item[1]


class LoadDataView(LoginRequiredMixin, View):
    login_url = '/login-views/'
    def get(self, request):
        print(request.user.username)
        qb = 'manager_qb'
        qn = 'manager_qn'
        username = request.user.username
        logging.basicConfig(level=logging.INFO)
        logging.debug("Log message goes here.")
        data = Survey.objects.all()

        if (username == qb):
            print('user 44')
            data = Survey_44.objects.all()
        else:
            if (username == qn):
                print('user51')
                data = Survey_51.objects.all()

        index2 = [1, 2]
        index3 = [1, 2, 3]
        index4 = [1, 2, 3, 4]
        index5 = [1, 2, 3, 4, 5]
        index6 = [1, 2, 3, 4, 5, 6]
        index7 = [1, 2, 3, 4, 5, 6, 7]
        index8 = [1, 2, 3, 4, 5, 6, 7, 8]
        for item in data:
            item.area = converttonumber(item.area, index4, 'area')
            item.nation = converttonumber(item.nation, index2, 'nation')
            item.gender = converttonumber(item.gender, index3, 'gender')
            item.age = converttonumber(item.age, index5, 'age')
            item.education = converttonumber(item.education, index7, 'education')
            item.children = converttonumber(item.children, index7, 'children')
            item.children_education = converttonumber(item.children_education, index8, 'children_education')
            item.distance = converttonumber(item.distance, index7, 'distance')
            item.people = converttonumber(item.people, index7, 'people')
            item.income = converttonumber(item.income, index5, 'income')
            item.footcrops1 = converttonumber(item.footcrops1, index5, 'footcrops1')
            item.footcrops2 = converttonumber(item.footcrops2, index5, 'footcrops2')
            item.treecommercial1 = converttonumber(item.treecommercial1, index5, 'treecommercial1')
            item.treecommercial2 = converttonumber(item.treecommercial2, index5, 'treecommercial2')
            item.breed1 = converttonumber(item.breed1, index5, 'breed1')
            item.breed2 = converttonumber(item.breed2, index5, 'breed2')
            item.employed1 = converttonumber(item.employed1, index5, 'employed1')
            item.employed2 = converttonumber(item.employed2, index5, 'employed2')
            item.spending1 = converttonumber(item.spending1, index5, 'spending1')
            item.spending2 = converttonumber(item.spending2, index5, 'spending2')
            item.ordinaryspending1 = converttonumber(item.ordinaryspending1, index5, 'ordinaryspending1')
            item.ordinaryspending2 = converttonumber(item.ordinaryspending2, index5, 'ordinaryspending2')
            item.agriculturalland1 = converttonumber(item.agriculturalland1, index5, 'agriculturalland1')
            item.agriculturalland2 = converttonumber(item.agriculturalland2, index5, 'agriculturalland2')
            item.bigpets1 = converttonumber(item.bigpets1, index5, 'bigpets1')
            item.bigpets2 = converttonumber(item.bigpets2, index5, 'bigpets2')
            item.average1 = converttonumber(item.average1, index5, 'average1')
            item.average2 = converttonumber(item.average2, index5, 'average2')
            item.smallpets1 = converttonumber(item.smallpets1, index5, 'smallpets1')
            item.smallpets2 = converttonumber(item.smallpets2, index5, 'smallpets2')
            item.fishpond1 = converttonumber(item.fishpond1, index5, 'fishpond1')
            item.fishpond2 = converttonumber(item.fishpond2, index5, 'fishpond2')
            item.agriculturaltools1 = converttonumber(item.agriculturaltools1, index5, 'agriculturaltools1')
            item.agriculturaltools2 = converttonumber(item.agriculturaltools2, index5, 'agriculturaltools2')
            item.machines1 = converttonumber(item.machines1, index5, 'machines1')
            item.machines2 = converttonumber(item.machines2, index5, 'machines2')
            # llllllllll
            item.device1 = converttonumber(item.device1, index5, 'device1')
            item.device2 = converttonumber(item.device2, index5, 'device2')
            item.home1 = converttonumber(item.home1, index5, 'home1')
            item.home2 = converttonumber(item.home2, index5, 'home2')
            item.belongings1 = converttonumber(item.belongings1, index5, 'belongings1')
            item.belongings2 = converttonumber(item.belongings2, index5, 'belongings2')
            item.smallbelongings1 = converttonumber(item.smallbelongings1, index5, 'smallbelongings1')
            item.smallbelongings2 = converttonumber(item.smallbelongings2, index5, 'smallbelongings2')
            item.phone1 = converttonumber(item.phone1, index5, 'phone1')
            item.phone2 = converttonumber(item.phone2, index5, 'phone2')
            item.nonagricultural1 = converttonumber(item.nonagricultural1, index5, 'nonagricultural1')
            item.nonagricultural2 = converttonumber(item.nonagricultural2, index5, 'nonagricultural2')
            item.vehicle1 = converttonumber(item.vehicle1, index5, 'vehicle1')
            item.vehicle2 = converttonumber(item.vehicle2, index5, 'vehicle2')
            # # llllll
            item.nongovernmental1 = converttonumber(item.nongovernmental1, index5, 'nongovernmental1')
            item.nongovernmental2 = converttonumber(item.nongovernmental2, index5, 'nongovernmental2')
            item.official1 = converttonumber(item.official1, index5, 'official1')
            item.official2 = converttonumber(item.official2, index5, 'official2')
            item.friend1 = converttonumber(item.friend1, index5, 'friend1')
            item.friend2 = converttonumber(item.friend2, index5, 'friend2')
            item.spendingfamily = converttonumber(item.spendingfamily, index5, 'spendingfamily')
            # # ppppppppp4
            item.trade1 = converttonumber(item.trade1, index5, 'trade1')
            item.trade2 = converttonumber(item.trade2, index6, 'trade2')
            item.forestry1 = converttonumber(item.forestry1, index5, 'forestry1')
            item.forestry2 = converttonumber(item.forestry2, index6, 'forestry2')
            item.finance1 = converttonumber(item.finance1, index5, 'finance1')
            item.finance2 = converttonumber(item.finance2, index6, 'finance2')
            item.insurance1 = converttonumber(item.insurance1, index5, 'insurance1')
            item.insurance2 = converttonumber(item.insurance2, index6, 'insurance2')
            item.business1 = converttonumber(item.business1, index5, 'business1')
            item.business2 = converttonumber(item.business2, index6, 'business2')
            item.charity1 = converttonumber(item.charity1, index5, 'charity1')
            item.charity2 = converttonumber(item.charity2, index6, 'charity2')
            item.religion1 = converttonumber(item.religion1, index5, 'religion1')
            item.religion2 = converttonumber(item.religion2, index6, 'religion2')
            item.work = converttonumber(item.work, index5, 'work')
            item.workof = converttonumber(item.workof, index5, 'workof')
        context = {
            "survey": data,
            "nation": NATION,
            "gender": GENDER,
            "area": AREA,
            "age": AGE,
            "education": EDUCATION,
            "children": CHILDREN,
            "children_education": EDUCATIONCHILDREN,
            "distance": DISTANCE,
            "people": PEOPLE,
            "income": INCOME,
            "decision": DECISION,
            "confidence": CONFIDENCE,
            "own": OWN,
            "loanamount": LoanAmount,
            "selectdecide": SelectDecide,
            "join": Join,
            "positivity": POSITIVITY,
            "work": WORK,
            "workof": WORKOF
        }
        return render(request, 'homepage/load-data.html', context)


def converttonumber(value, index2, constant):
    listItem = []
    if constant == 'nation':
        data = NATION
        for item in data:
            listItem.append(item[0])
    if constant == 'area':
        data = AREA
        for item in data:
            listItem.append(item[0])
    if constant == 'gender':
        data = GENDER
        for item in data:
            listItem.append(item[0])
    if constant == 'age':
        data = AGE
        for item in data:
            listItem.append(item[0])
    if constant == 'education':
        data = EDUCATION
        for item in data:
            listItem.append(item[0])
    if constant == 'children':
        data = CHILDREN
        for item in data:
            listItem.append(item[0])
    if constant == 'children_education':
        data = EDUCATIONCHILDREN
        for item in data:
            listItem.append(item[0])
    if constant == 'distance':
        data = DISTANCE
        for item in data:
            listItem.append(item[0])
    if constant == 'people':
        data = PEOPLE
        for item in data:
            listItem.append(item[0])
    if constant == 'income':
        data = INCOME
        for item in data:
            listItem.append(item[0])
    if constant == 'footcrops1':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'footcrops2':
        data = CONFIDENCE
        for item in data:
            listItem.append(item[0])
    if constant == 'treecommercial1':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'treecommercial2':
        data = CONFIDENCE
        for item in data:
            listItem.append(item[0])
    if constant == 'breed1':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'breed2':
        data = CONFIDENCE
        for item in data:
            listItem.append(item[0])
    if constant == 'employed1':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'employed2':
        data = CONFIDENCE
        for item in data:
            listItem.append(item[0])
    if constant == 'spending1':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'spending2':
        data = CONFIDENCE
        for item in data:
            listItem.append(item[0])
    if constant == 'ordinaryspending1':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'ordinaryspending2':
        data = CONFIDENCE
        for item in data:
            listItem.append(item[0])
    if constant == 'agriculturalland1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'agriculturalland2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'bigpets1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'bigpets2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'average1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'average2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'smallpets1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'smallpets2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'fishpond1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'fishpond2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'agriculturaltools1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'agriculturaltools2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'machines1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'machines2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    # lllllllllllll
    if constant == 'device1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'device2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'home1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'home2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'belongings1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'belongings2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'smallbelongings1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'smallbelongings2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'phone1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'phone2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'nonagricultural1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'nonagricultural2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    if constant == 'vehicle1':
        data = OWN
        for item in data:
            listItem.append(item[0])
    if constant == 'vehicle2':
        data = DECISION
        for item in data:
            listItem.append(item[0])
    # llllll
    if constant == 'nongovernmental1':
        data = LoanAmount
        for item in data:
            listItem.append(item[0])
    if constant == 'nongovernmental2':
        data = SelectDecide
        for item in data:
            listItem.append(item[0])
    if constant == 'official1':
        data = LoanAmount
        for item in data:
            listItem.append(item[0])
    if constant == 'official2':
        data = SelectDecide
        for item in data:
            listItem.append(item[0])
    if constant == 'friend1':
        data = LoanAmount
        for item in data:
            listItem.append(item[0])
    if constant == 'friend2':
        data = SelectDecide
        for item in data:
            listItem.append(item[0])
    if constant == 'spendingfamily':
        data = SelectDecide
        for item in data:
            listItem.append(item[0])
    # ppppppppppp4
    if constant == 'trade1':
        data = Join
        for item in data:
            listItem.append(item[0])
    if constant == 'trade2':
        data = POSITIVITY
        for item in data:
            listItem.append(item[0])
    if constant == 'forestry1':
        data = Join
        for item in data:
            listItem.append(item[0])
    if constant == 'forestry2':
        data = POSITIVITY
        for item in data:
            listItem.append(item[0])
    if constant == 'finance1':
        data = Join
        for item in data:
            listItem.append(item[0])
    if constant == 'finance2':
        data = POSITIVITY
        for item in data:
            listItem.append(item[0])
    if constant == 'insurance1':
        data = Join
        for item in data:
            listItem.append(item[0])
    if constant == 'insurance2':
        data = POSITIVITY
        for item in data:
            listItem.append(item[0])
    if constant == 'business1':
        data = Join
        for item in data:
            listItem.append(item[0])
    if constant == 'business2':
        data = POSITIVITY
        for item in data:
            listItem.append(item[0])
    if constant == 'charity1':
        data = Join
        for item in data:
            listItem.append(item[0])
    if constant == 'charity2':
        data = POSITIVITY
        for item in data:
            listItem.append(item[0])
    if constant == 'religion1':
        data = Join
        for item in data:
            listItem.append(item[0])
    if constant == 'religion2':
        data = POSITIVITY
        for item in data:
            listItem.append(item[0])
    if constant == 'work':
        data = WORK
        for item in data:
            listItem.append(item[0])
    if constant == 'workof':
        data = WORKOF
        for item in data:
            listItem.append(item[0])

    s = pd.Series(listItem, index=index2)

    for item in s.iteritems():
        if item[1] == value:
            return item[0]

    return '--'


class DescribeDataView(LoginRequiredMixin, View):
    login_url = '/login-views/'

    def get(self, request):
        print(request.user.username)
        qb = 'manager_qb'
        qn = 'manager_qn'
        username = request.user.username
        logging.basicConfig(level=logging.INFO)
        logging.debug("Log message goes here.")
        data = Survey.objects.all()

        if (username == qb):
            print('user 44')
            data = Survey_44.objects.all()
        else:
            if (username == qn):
                print('user51')
                data = Survey_51.objects.all()

        # data
        index2 = [1, 2]
        index3 = [1, 2, 3]
        index4 = [1, 2, 3, 4]
        index5 = [1, 2, 3, 4, 5]
        index6 = [1, 2, 3, 4, 5, 6]
        index7 = [1, 2, 3, 4, 5, 6, 7]
        index8 = [1, 2, 3, 4, 5, 6, 7, 8]
        for item in data:
            item.area = converttonumber(item.area, index4, 'area')
            item.nation = converttonumber(item.nation, index2, 'nation')
            item.gender = converttonumber(item.gender, index3, 'gender')
            item.age = converttonumber(item.age, index5, 'age')
            item.education = converttonumber(item.education, index7, 'education')
            item.children = converttonumber(item.children, index7, 'children')
            item.children_education = converttonumber(item.children_education, index8, 'children_education')
            item.distance = converttonumber(item.distance, index7, 'distance')
            item.people = converttonumber(item.people, index7, 'people')
            item.income = converttonumber(item.income, index5, 'income')
            item.footcrops1 = converttonumber(item.footcrops1, index5, 'footcrops1')
            item.footcrops2 = converttonumber(item.footcrops2, index5, 'footcrops2')
            item.treecommercial1 = converttonumber(item.treecommercial1, index5, 'treecommercial1')
            item.treecommercial2 = converttonumber(item.treecommercial2, index5, 'treecommercial2')
            item.breed1 = converttonumber(item.breed1, index5, 'breed1')
            item.breed2 = converttonumber(item.breed2, index5, 'breed2')
            item.employed1 = converttonumber(item.employed1, index5, 'employed1')
            item.employed2 = converttonumber(item.employed2, index5, 'employed2')
            item.spending1 = converttonumber(item.spending1, index5, 'spending1')
            item.spending2 = converttonumber(item.spending2, index5, 'spending2')
            item.ordinaryspending1 = converttonumber(item.ordinaryspending1, index5, 'ordinaryspending1')
            item.ordinaryspending2 = converttonumber(item.ordinaryspending2, index5, 'ordinaryspending2')
            item.agriculturalland1 = converttonumber(item.agriculturalland1, index5, 'agriculturalland1')
            item.agriculturalland2 = converttonumber(item.agriculturalland2, index5, 'agriculturalland2')
            item.bigpets1 = converttonumber(item.bigpets1, index5, 'bigpets1')
            item.bigpets2 = converttonumber(item.bigpets2, index5, 'bigpets2')
            item.average1 = converttonumber(item.average1, index5, 'average1')
            item.average2 = converttonumber(item.average2, index5, 'average2')
            item.smallpets1 = converttonumber(item.smallpets1, index5, 'smallpets1')
            item.smallpets2 = converttonumber(item.smallpets2, index5, 'smallpets2')
            item.fishpond1 = converttonumber(item.fishpond1, index5, 'fishpond1')
            item.fishpond2 = converttonumber(item.fishpond2, index5, 'fishpond2')
            item.agriculturaltools1 = converttonumber(item.agriculturaltools1, index5, 'agriculturaltools1')
            item.agriculturaltools2 = converttonumber(item.agriculturaltools2, index5, 'agriculturaltools2')
            item.machines1 = converttonumber(item.machines1, index5, 'machines1')
            item.machines2 = converttonumber(item.machines2, index5, 'machines2')
            # llllllllll
            item.device1 = converttonumber(item.device1, index5, 'device1')
            item.device2 = converttonumber(item.device2, index5, 'device2')
            item.home1 = converttonumber(item.home1, index5, 'home1')
            item.home2 = converttonumber(item.home2, index5, 'home2')
            item.belongings1 = converttonumber(item.belongings1, index5, 'belongings1')
            item.belongings2 = converttonumber(item.belongings2, index5, 'belongings2')
            item.smallbelongings1 = converttonumber(item.smallbelongings1, index5, 'smallbelongings1')
            item.smallbelongings2 = converttonumber(item.smallbelongings2, index5, 'smallbelongings2')
            item.phone1 = converttonumber(item.phone1, index5, 'phone1')
            item.phone2 = converttonumber(item.phone2, index5, 'phone2')
            item.nonagricultural1 = converttonumber(item.nonagricultural1, index5, 'nonagricultural1')
            item.nonagricultural2 = converttonumber(item.nonagricultural2, index5, 'nonagricultural2')
            item.vehicle1 = converttonumber(item.vehicle1, index5, 'vehicle1')
            item.vehicle2 = converttonumber(item.vehicle2, index5, 'vehicle2')
            # # llllll
            item.nongovernmental1 = converttonumber(item.nongovernmental1, index5, 'nongovernmental1')
            item.nongovernmental2 = converttonumber(item.nongovernmental2, index5, 'nongovernmental2')
            item.official1 = converttonumber(item.official1, index5, 'official1')
            item.official2 = converttonumber(item.official2, index5, 'official2')
            item.friend1 = converttonumber(item.friend1, index5, 'friend1')
            item.friend2 = converttonumber(item.friend2, index5, 'friend2')
            item.spendingfamily = converttonumber(item.spendingfamily, index5, 'spendingfamily')
            # # ppppppppp4
            item.trade1 = converttonumber(item.trade1, index5, 'trade1')
            item.trade2 = converttonumber(item.trade2, index6, 'trade2')
            item.forestry1 = converttonumber(item.forestry1, index5, 'forestry1')
            item.forestry2 = converttonumber(item.forestry2, index6, 'forestry2')
            item.finance1 = converttonumber(item.finance1, index5, 'finance1')
            item.finance2 = converttonumber(item.finance2, index6, 'finance2')
            item.insurance1 = converttonumber(item.insurance1, index5, 'insurance1')
            item.insurance2 = converttonumber(item.insurance2, index6, 'insurance2')
            item.business1 = converttonumber(item.business1, index5, 'business1')
            item.business2 = converttonumber(item.business2, index6, 'business2')
            item.charity1 = converttonumber(item.charity1, index5, 'charity1')
            item.charity2 = converttonumber(item.charity2, index6, 'charity2')
            item.religion1 = converttonumber(item.religion1, index5, 'religion1')
            item.religion2 = converttonumber(item.religion2, index6, 'religion2')
            item.work = converttonumber(item.work, index5, 'work')
            item.workof = converttonumber(item.workof, index5, 'workof')
        data_frame = []

        for item in data:
            temp = {}
            temp['Loại địa bàn'] = item.area
            temp['Dân tộc'] = item.nation
            temp['Giới tính'] = item.gender
            temp['Độ tuổi'] = item.age
            temp['Học vấn cao nhất của người được hỏi'] = item.education
            temp['Số con trong gia đình'] = item.children
            temp['Học vấn cao nhất của con'] = item.children_education
            temp['Khoảng cách đến đô thị'] = item.distance
            temp['Số nhân khẩu trong gia đình'] = item.people
            temp['Tổng thu nhập hộ gia đình/tháng'] = item.income
            temp['Quyết định trồng cây lương thực'] = item.footcrops1
            temp['Mức độ tự tin trồng cây lương thực'] = item.footcrops2
            temp['Quyết định trồng cây thương mại'] = item.treecommercial1
            temp['Mức độ tự tin trồng cây thương mại'] = item.treecommercial2
            temp['Quyết định về hoạt động chăn nuôi'] = item.breed1
            temp['Mức độ tự tin về hoạt động chăn nuôi'] = item.breed2
            temp['Quyết định về làm thuê được trả lương'] = item.employed1
            temp['Mức độ tự tin về làm thuê được trả lương'] = item.employed2
            temp['Quyết định về hoạt động chi tiêu lớn'] = item.spending1
            temp['Mức độ tự tin về hoạt động chi tiêu lớn'] = item.spending2
            temp['Quyết định về hoạt động chi tiêu thông thường'] = item.ordinaryspending1
            temp['Mức độ tự tin về hoạt động chi tiêu thông thường'] = item.ordinaryspending2
            temp['Quyền sở hữu tài sản đất nông nghiệp'] = item.agriculturalland1
            temp['Tài sản ĐNN thực hiện cùng với ai?'] = item.agriculturalland2
            temp['Quyền sở hữu tài sản vật nuôi lớn'] = item.bigpets1
            temp['Tài sản VNL thực hiện cùng với ai?'] = item.bigpets2
            temp['Quyền sở hữu tài sản vật nuôi trung bình'] = item.average1
            temp['Tài sản VNTB thực hiện cùng với ai?'] = item.average2
            temp['Quyền sở hữu tài sản vật nuôi nhỏ'] = item.smallpets1
            temp['Tài sản VNN thực hiện cùng với ai?'] = item.smallpets2
            temp['Quyền sở hữu tài sản ao nuôi cá'] = item.fishpond1
            temp['Tài sản ANC thực hiện cùng với ai?'] = item.fishpond2
            temp['Quyền sở hữu tài sản dụng cụ nông nghiệp'] = item.agriculturaltools1
            temp['Tài sản DCNN thực hiện cùng với ai?'] = item.agriculturaltools2
            temp['Quyền sở hữu tài sản máy móc nông nghiệp'] = item.machines1
            temp['Tài sản MMNN thực hiện cùng với ai?'] = item.machines2
            # llllllllll
            temp['Quyền sở hữu tài sản thiết bị phi nông nghiệp'] = item.device1
            temp['Tài sản TBPNN thực hiện cùng với ai?'] = item.device2
            temp['Quyền sở hữu tài sản nhà ở'] = item.home1
            temp['Tài sản nhà ở thực hiện cùng với ai?'] = item.home2
            temp['Quyền sở hữu tài sản đồ dùng lâu bền loại lớn'] = item.belongings1
            temp['Tài sản ĐDLL thực hiện cùng với ai?'] = item.belongings2
            temp['Quyền sở hữu tài sản đồ dùng lâu bền loại nhỏ'] = item.smallbelongings1
            temp['Tài sản ĐDLN thực hiện cùng với ai?'] = item.smallbelongings2
            temp['Quyền sở hữu tài sản thiết bị điện thoại'] = item.phone1
            temp['Tài sản ĐT thực hiện cùng với ai?'] = item.phone2
            temp['Quyền sở hữu tài sản đất phi nông nghiệp'] = item.nonagricultural1
            temp['Tài sản ĐPNN thực hiện cùng với ai?'] = item.nonagricultural2
            temp['Quyền sở hữu tài sản phương tiện giao thông'] = item.vehicle1
            temp['Tài sản PTGT thực hiện cùng với ai?'] = item.vehicle2
            temp['Quyền vay mượn từ các tổ chức phi chính phủ'] = item.nongovernmental1
            temp['Quyền quyết định vay từ các tổ chức phi chính phủ'] = item.nongovernmental2
            temp['Quyền vay mượn từ các tổ chức tín dụng chính thức'] = item.official1
            temp['Quyền quyết định vay từ các tổ chức tín dụng chính thức'] = item.official2
            temp['Quyền vay mượn từ bạn bè hoặc họ hàng, người thân'] = item.friend1
            temp['Quyền quyết định vay từ bạn bè hoặc họ hàng, người thân'] = item.friend2
            temp['Quyết định chi tiêu hộ gia đình được thực hiện'] = item.spendingfamily
            temp['Tham gia xã hội về các tổ chức nông nghiệp'] = item.trade1
            temp['Tham gia tích cực về các tổ chức nông nghiệp'] = item.trade2
            temp['Tham gia xã hội về các tổ chức lâm nghiệp'] = item.forestry1
            temp['Tham gia tích cực về các tổ chức lâm nghiệp'] = item.forestry2
            temp['Tham gia xã hội về các tổ chức tín dụng'] = item.finance1
            temp['Tham gia tích cực về các tổ chức tín dụng'] = item.finance2
            temp['Tham gia xã hội về các tổ chức hỗ trợ'] = item.insurance1
            temp['Tham gia tích cực về các tổ chức hỗ trợ'] = item.insurance2
            temp['Tham gia xã hội về các hiệp hội thương mại'] = item.business1
            temp['Tham gia tích cực về các hiệp hội thương mại'] = item.business2
            temp['Tham gia xã hội về hỗ trợ cộng đồng'] = item.charity1
            temp['Tham gia tích cực về hỗ trợ cộng đồng'] = item.charity2
            temp['Tham gia xã hội về các tổ chức tôn giáo'] = item.religion1
            temp['Tham gia tích cực về các tổ chức tôn giáo'] = item.religion2
            temp['Khoảng thời gian làm việc trong ngày'] = item.work
            temp['Khoảng thời gian nghỉ ngơi trong ngày'] = item.workof
            data_frame.append(temp)

        df = pd.DataFrame(data_frame)
        df1 = df.T

        context = {
            "table_html": df.describe().T.to_html(),
            "survey": data,
            "nation": NATION,
            "gender": GENDER,
            "area": AREA,
            "age": AGE,
            "education": EDUCATION,
            "children": CHILDREN,
            "children_education": EDUCATIONCHILDREN,
            "distance": DISTANCE,
            "people": PEOPLE,
            "income": INCOME,
            "decision": DECISION,
            "confidence": CONFIDENCE,
            "own": OWN,
            "loanamount": LoanAmount,
            "selectdecide": SelectDecide,
            "join": Join,
            "positivity": POSITIVITY,
            "work": WORK,
            "workof": WORKOF
        }
        return render(request, 'homepage/describe-data.html', context)


class ComputingFieldsView(LoginRequiredMixin, View):
    login_url = '/login-views/'

    def get(self, request):
        print(request.user.username)
        qb = 'manager_qb'
        qn = 'manager_qn'
        username = request.user.username
        logging.basicConfig(level=logging.INFO)
        logging.debug("Log message goes here.")
        data = Survey.objects.all()
        # data = Survey_44.objects.all()
        if (username == qb):
            print('user 44')
            data = Survey_44.objects.all()
        else:
            if (username == qn):
                print('user51')
                data = Survey_51.objects.all()

        # data
        index2 = [1, 2]
        index3 = [1, 2, 3]
        index4 = [1, 2, 3, 4]
        index5 = [1, 2, 3, 4, 5]
        index6 = [1, 2, 3, 4, 5, 6]
        index7 = [1, 2, 3, 4, 5, 6, 7]
        index8 = [1, 2, 3, 4, 5, 6, 7, 8]
        for item in data:
            item.area = converttonumber(item.area, index4, 'area')
            item.nation = converttonumber(item.nation, index2, 'nation')
            item.gender = converttonumber(item.gender, index3, 'gender')
            item.age = converttonumber(item.age, index5, 'age')
            item.education = converttonumber(item.education, index7, 'education')
            item.children = converttonumber(item.children, index7, 'children')
            item.children_education = converttonumber(item.children_education, index8, 'children_education')
            item.distance = converttonumber(item.distance, index7, 'distance')
            item.people = converttonumber(item.people, index7, 'people')
            item.income = converttonumber(item.income, index5, 'income')
            item.footcrops1 = converttonumber(item.footcrops1, index5, 'footcrops1')
            item.footcrops2 = converttonumber(item.footcrops2, index5, 'footcrops2')
            item.treecommercial1 = converttonumber(item.treecommercial1, index5, 'treecommercial1')
            item.treecommercial2 = converttonumber(item.treecommercial2, index5, 'treecommercial2')
            item.breed1 = converttonumber(item.breed1, index5, 'breed1')
            item.breed2 = converttonumber(item.breed2, index5, 'breed2')
            item.employed1 = converttonumber(item.employed1, index5, 'employed1')
            item.employed2 = converttonumber(item.employed2, index5, 'employed2')
            item.spending1 = converttonumber(item.spending1, index5, 'spending1')
            item.spending2 = converttonumber(item.spending2, index5, 'spending2')
            item.ordinaryspending1 = converttonumber(item.ordinaryspending1, index5, 'ordinaryspending1')
            item.ordinaryspending2 = converttonumber(item.ordinaryspending2, index5, 'ordinaryspending2')
            item.agriculturalland1 = converttonumber(item.agriculturalland1, index5, 'agriculturalland1')
            item.agriculturalland2 = converttonumber(item.agriculturalland2, index5, 'agriculturalland2')
            item.bigpets1 = converttonumber(item.bigpets1, index5, 'bigpets1')
            item.bigpets2 = converttonumber(item.bigpets2, index5, 'bigpets2')
            item.average1 = converttonumber(item.average1, index5, 'average1')
            item.average2 = converttonumber(item.average2, index5, 'average2')
            item.smallpets1 = converttonumber(item.smallpets1, index5, 'smallpets1')
            item.smallpets2 = converttonumber(item.smallpets2, index5, 'smallpets2')
            item.fishpond1 = converttonumber(item.fishpond1, index5, 'fishpond1')
            item.fishpond2 = converttonumber(item.fishpond2, index5, 'fishpond2')
            item.agriculturaltools1 = converttonumber(item.agriculturaltools1, index5, 'agriculturaltools1')
            item.agriculturaltools2 = converttonumber(item.agriculturaltools2, index5, 'agriculturaltools2')
            item.machines1 = converttonumber(item.machines1, index5, 'machines1')
            item.machines2 = converttonumber(item.machines2, index5, 'machines2')
            # llllllllll
            item.device1 = converttonumber(item.device1, index5, 'device1')
            item.device2 = converttonumber(item.device2, index5, 'device2')
            item.home1 = converttonumber(item.home1, index5, 'home1')
            item.home2 = converttonumber(item.home2, index5, 'home2')
            item.belongings1 = converttonumber(item.belongings1, index5, 'belongings1')
            item.belongings2 = converttonumber(item.belongings2, index5, 'belongings2')
            item.smallbelongings1 = converttonumber(item.smallbelongings1, index5, 'smallbelongings1')
            item.smallbelongings2 = converttonumber(item.smallbelongings2, index5, 'smallbelongings2')
            item.phone1 = converttonumber(item.phone1, index5, 'phone1')
            item.phone2 = converttonumber(item.phone2, index5, 'phone2')
            item.nonagricultural1 = converttonumber(item.nonagricultural1, index5, 'nonagricultural1')
            item.nonagricultural2 = converttonumber(item.nonagricultural2, index5, 'nonagricultural2')
            item.vehicle1 = converttonumber(item.vehicle1, index5, 'vehicle1')
            item.vehicle2 = converttonumber(item.vehicle2, index5, 'vehicle2')
            # # llllll
            item.nongovernmental1 = converttonumber(item.nongovernmental1, index5, 'nongovernmental1')
            item.nongovernmental2 = converttonumber(item.nongovernmental2, index5, 'nongovernmental2')
            item.official1 = converttonumber(item.official1, index5, 'official1')
            item.official2 = converttonumber(item.official2, index5, 'official2')
            item.friend1 = converttonumber(item.friend1, index5, 'friend1')
            item.friend2 = converttonumber(item.friend2, index5, 'friend2')
            item.spendingfamily = converttonumber(item.spendingfamily, index5, 'spendingfamily')
            # # ppppppppp4
            item.trade1 = converttonumber(item.trade1, index5, 'trade1')
            item.trade2 = converttonumber(item.trade2, index6, 'trade2')
            item.forestry1 = converttonumber(item.forestry1, index5, 'forestry1')
            item.forestry2 = converttonumber(item.forestry2, index6, 'forestry2')
            item.finance1 = converttonumber(item.finance1, index5, 'finance1')
            item.finance2 = converttonumber(item.finance2, index6, 'finance2')
            item.insurance1 = converttonumber(item.insurance1, index5, 'insurance1')
            item.insurance2 = converttonumber(item.insurance2, index6, 'insurance2')
            item.business1 = converttonumber(item.business1, index5, 'business1')
            item.business2 = converttonumber(item.business2, index6, 'business2')
            item.charity1 = converttonumber(item.charity1, index5, 'charity1')
            item.charity2 = converttonumber(item.charity2, index6, 'charity2')
            item.religion1 = converttonumber(item.religion1, index5, 'religion1')
            item.religion2 = converttonumber(item.religion2, index6, 'religion2')
            item.work = converttonumber(item.work, index5, 'work')
            item.workof = converttonumber(item.workof, index5, 'workof')

        export_data = []
        id = 0
        for item in data:
            temp = []
            temp.append(id)
            id = id + 1
            tbsx = round((item.footcrops1 + item.treecommercial1 + item.breed1 + item.employed1 + item.footcrops2 + \
                          item.treecommercial2 + item.breed2 + item.employed2) / 8, 3)
            temp.append(tbsx)
            tbnl = round(
                (item.machines1 + item.agriculturalland1 + item.bigpets1 + item.agriculturaltools1 + item.home1
                 + item.nonagricultural1 + item.machines2 + item.agriculturalland2 + item.bigpets2
                 + item.agriculturaltools2 + item.home2 + item.nonagricultural2 + item.official1
                 + item.nongovernmental1 + item.friend1) / 15, 3)
            temp.append(tbnl)
            tngd = item.income
            temp.append(tngd)
            tbtgxh = round((item.insurance1 + item.forestry1 + item.charity1 + item.insurance2 + item.forestry2
                            + item.charity2) / 6, 3)
            temp.append(tbtgxh)
            tbsdtg = round((item.work + item.workof) / 2, 3)
            temp.append(tbsdtg)
            tbtqcc = round((tbsx + tbnl * 0.5 + tngd * 2 + tbtgxh + tbsdtg) / 5, 3)
            temp.append(tbtqcc)
            tbtqccX2 = round(tbtqcc * 2, 3)
            temp.append(tbtqccX2)
            traoquyen = 0
            if (tbtqccX2 / 10 > 0.6):
                traoquyen = 1
            else:
                traoquyen = 0
            temp.append(traoquyen)
            export_data.append(temp)

        context = {
            "export_data": export_data,
            "survey": data,
            "nation": NATION,
            "gender": GENDER,
            "area": AREA,
            "age": AGE,
            "education": EDUCATION,
            "children": CHILDREN,
            "children_education": EDUCATIONCHILDREN,
            "distance": DISTANCE,
            "people": PEOPLE,
            "income": INCOME,
            "decision": DECISION,
            "confidence": CONFIDENCE,
            "own": OWN,
            "loanamount": LoanAmount,
            "selectdecide": SelectDecide,
            "join": Join,
            "positivity": POSITIVITY,
            "work": WORK,
            "workof": WORKOF,
        }
        return render(request, 'homepage/computing-fields.html', context)


class ComputingChartsView(LoginRequiredMixin, View):
    def get(self, request, namechart):
        qb = 'manager_qb'
        qn = 'manager_qn'
        username = request.user.username
        logging.basicConfig(level=logging.INFO)
        logging.debug("Log message goes here.")
        data = Survey.objects.all()

        if (username == qb):
            print('user 44')
            data = Survey_44.objects.all()
        else:
            if (username == qn):
                print('user51')
                data = Survey_51.objects.all()

        # data
        index2 = [1, 2]
        index3 = [1, 2, 3]
        index4 = [1, 2, 3, 4]
        index5 = [1, 2, 3, 4, 5]
        index6 = [1, 2, 3, 4, 5, 6]
        index7 = [1, 2, 3, 4, 5, 6, 7]
        index8 = [1, 2, 3, 4, 5, 6, 7, 8]
        for item in data:
            item.area = converttonumber(item.area, index4, 'area')
            item.nation = converttonumber(item.nation, index2, 'nation')
            item.gender = converttonumber(item.gender, index3, 'gender')
            item.age = converttonumber(item.age, index5, 'age')
            item.education = converttonumber(item.education, index7, 'education')
            item.children = converttonumber(item.children, index7, 'children')
            item.children_education = converttonumber(item.children_education, index8, 'children_education')
            item.distance = converttonumber(item.distance, index7, 'distance')
            item.people = converttonumber(item.people, index7, 'people')
            item.income = converttonumber(item.income, index5, 'income')
            item.footcrops1 = converttonumber(item.footcrops1, index5, 'footcrops1')
            item.footcrops2 = converttonumber(item.footcrops2, index5, 'footcrops2')
            item.treecommercial1 = converttonumber(item.treecommercial1, index5, 'treecommercial1')
            item.treecommercial2 = converttonumber(item.treecommercial2, index5, 'treecommercial2')
            item.breed1 = converttonumber(item.breed1, index5, 'breed1')
            item.breed2 = converttonumber(item.breed2, index5, 'breed2')
            item.employed1 = converttonumber(item.employed1, index5, 'employed1')
            item.employed2 = converttonumber(item.employed2, index5, 'employed2')
            item.spending1 = converttonumber(item.spending1, index5, 'spending1')
            item.spending2 = converttonumber(item.spending2, index5, 'spending2')
            item.ordinaryspending1 = converttonumber(item.ordinaryspending1, index5, 'ordinaryspending1')
            item.ordinaryspending2 = converttonumber(item.ordinaryspending2, index5, 'ordinaryspending2')
            item.agriculturalland1 = converttonumber(item.agriculturalland1, index5, 'agriculturalland1')
            item.agriculturalland2 = converttonumber(item.agriculturalland2, index5, 'agriculturalland2')
            item.bigpets1 = converttonumber(item.bigpets1, index5, 'bigpets1')
            item.bigpets2 = converttonumber(item.bigpets2, index5, 'bigpets2')
            item.average1 = converttonumber(item.average1, index5, 'average1')
            item.average2 = converttonumber(item.average2, index5, 'average2')
            item.smallpets1 = converttonumber(item.smallpets1, index5, 'smallpets1')
            item.smallpets2 = converttonumber(item.smallpets2, index5, 'smallpets2')
            item.fishpond1 = converttonumber(item.fishpond1, index5, 'fishpond1')
            item.fishpond2 = converttonumber(item.fishpond2, index5, 'fishpond2')
            item.agriculturaltools1 = converttonumber(item.agriculturaltools1, index5, 'agriculturaltools1')
            item.agriculturaltools2 = converttonumber(item.agriculturaltools2, index5, 'agriculturaltools2')
            item.machines1 = converttonumber(item.machines1, index5, 'machines1')
            item.machines2 = converttonumber(item.machines2, index5, 'machines2')
            # llllllllll
            item.device1 = converttonumber(item.device1, index5, 'device1')
            item.device2 = converttonumber(item.device2, index5, 'device2')
            item.home1 = converttonumber(item.home1, index5, 'home1')
            item.home2 = converttonumber(item.home2, index5, 'home2')
            item.belongings1 = converttonumber(item.belongings1, index5, 'belongings1')
            item.belongings2 = converttonumber(item.belongings2, index5, 'belongings2')
            item.smallbelongings1 = converttonumber(item.smallbelongings1, index5, 'smallbelongings1')
            item.smallbelongings2 = converttonumber(item.smallbelongings2, index5, 'smallbelongings2')
            item.phone1 = converttonumber(item.phone1, index5, 'phone1')
            item.phone2 = converttonumber(item.phone2, index5, 'phone2')
            item.nonagricultural1 = converttonumber(item.nonagricultural1, index5, 'nonagricultural1')
            item.nonagricultural2 = converttonumber(item.nonagricultural2, index5, 'nonagricultural2')
            item.vehicle1 = converttonumber(item.vehicle1, index5, 'vehicle1')
            item.vehicle2 = converttonumber(item.vehicle2, index5, 'vehicle2')
            # # llllll
            item.nongovernmental1 = converttonumber(item.nongovernmental1, index5, 'nongovernmental1')
            item.nongovernmental2 = converttonumber(item.nongovernmental2, index5, 'nongovernmental2')
            item.official1 = converttonumber(item.official1, index5, 'official1')
            item.official2 = converttonumber(item.official2, index5, 'official2')
            item.friend1 = converttonumber(item.friend1, index5, 'friend1')
            item.friend2 = converttonumber(item.friend2, index5, 'friend2')
            item.spendingfamily = converttonumber(item.spendingfamily, index5, 'spendingfamily')
            # # ppppppppp4
            item.trade1 = converttonumber(item.trade1, index5, 'trade1')
            item.trade2 = converttonumber(item.trade2, index6, 'trade2')
            item.forestry1 = converttonumber(item.forestry1, index5, 'forestry1')
            item.forestry2 = converttonumber(item.forestry2, index6, 'forestry2')
            item.finance1 = converttonumber(item.finance1, index5, 'finance1')
            item.finance2 = converttonumber(item.finance2, index6, 'finance2')
            item.insurance1 = converttonumber(item.insurance1, index5, 'insurance1')
            item.insurance2 = converttonumber(item.insurance2, index6, 'insurance2')
            item.business1 = converttonumber(item.business1, index5, 'business1')
            item.business2 = converttonumber(item.business2, index6, 'business2')
            item.charity1 = converttonumber(item.charity1, index5, 'charity1')
            item.charity2 = converttonumber(item.charity2, index6, 'charity2')
            item.religion1 = converttonumber(item.religion1, index5, 'religion1')
            item.religion2 = converttonumber(item.religion2, index6, 'religion2')
            item.work = converttonumber(item.work, index5, 'work')
            item.workof = converttonumber(item.workof, index5, 'workof')

        export_data = []
        id = 0
        for item in data:
            temp = []
            temp.append(id)
            id = id + 1
            tbsx = round((item.footcrops1 + item.treecommercial1 + item.breed1 + item.employed1 + item.footcrops2 + \
                          item.treecommercial2 + item.breed2 + item.employed2) / 8, 3)
            temp.append(tbsx)
            tbnl = round(
                (item.machines1 + item.agriculturalland1 + item.bigpets1 + item.agriculturaltools1 + item.home1
                 + item.nonagricultural1 + item.machines2 + item.agriculturalland2 + item.bigpets2
                 + item.agriculturaltools2 + item.home2 + item.nonagricultural2 + item.official1
                 + item.nongovernmental1 + item.friend1) / 15, 3)
            temp.append(tbnl)
            tngd = item.income
            temp.append(tngd)
            tbtgxh = round((item.insurance1 + item.forestry1 + item.charity1 + item.insurance2 + item.forestry2
                            + item.charity2) / 6, 3)
            temp.append(tbtgxh)
            tbsdtg = round((item.work + item.workof) / 2, 3)
            temp.append(tbsdtg)
            tbtqcc = round((tbsx + tbnl * 0.5 + tngd * 2 + tbtgxh + tbsdtg) / 5, 3)
            temp.append(tbtqcc)
            tbtqccX2 = round(tbtqcc * 2, 3)
            temp.append(tbtqccX2)
            traoquyen = 0
            if (tbtqccX2 / 10 > 0.6):
                traoquyen = 1
            else:
                traoquyen = 0
            temp.append(traoquyen)
            export_data.append(temp)


        #clear
        plt.clf()
        if namechart == 'charts-1':
            # create dataset
            height = [0, 0, 0, 0, 0]
            bars = ('1', '2', '3', '4', '5')
            for item in export_data:
                # print(item[1])
                if item[1] <= 1:
                    height[0]=height[0]+1
                elif item[1] <= 2:
                    height[1] = height[1] + 1
                elif item[1] <= 3:
                    height[2] = height[2] + 1
                elif item[1] <= 4:
                    height[3] = height[3] + 1
                elif item[1] <= 5:
                    height[4] = height[4] + 1

            x_pos = np.arange(len(bars))

            # Create bars and choose color
            plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))

            # Add title and axis names
            plt.title('Biểu đồ TBSX')
            plt.xlabel('TRUNG BÌNH BIẾN SỐ SẢN XUẤT')
            plt.ylabel('Số lượng')

            # Create names on the x axis
            plt.xticks(x_pos, bars)

        elif namechart == 'charts-2':
            # create dataset
            height = [0, 0, 0, 0, 0]
            bars = ('1', '2', '3', '4', '5')
            for item in export_data:
                if item[2] <= 1:
                    height[0] = height[0] + 1
                elif item[2] <= 2:
                    height[1] = height[1] + 1
                elif item[2] <= 3:
                    height[2] = height[2] + 1
                elif item[2] <= 4:
                    height[3] = height[3] + 1
                elif item[2] <= 5:
                    height[4] = height[4] + 1

            x_pos = np.arange(len(bars))

            # Create bars and choose color
            plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))

            # Add title and axis names
            plt.title('TRUNG BÌNH BIẾN SỐ NGUỒN LỰC')
            plt.xlabel('TB_NL_x_0.5')
            plt.ylabel('Số lượng')

            # Create names on the x axis
            plt.xticks(x_pos, bars)
        elif namechart == 'charts-3':
            # create dataset
            height = [0, 0, 0, 0, 0]
            bars = ('1', '2', '3', '4', '5')
            for item in export_data:
                if item[3] <= 1:
                    height[0] = height[0] + 1
                elif item[3] <= 2:
                    height[1] = height[1] + 1
                elif item[3] <= 3:
                    height[2] = height[2] + 1
                elif item[3] <= 4:
                    height[3] = height[3] + 1
                elif item[3] <= 5:
                    height[4] = height[4] + 1

            x_pos = np.arange(len(bars))

            # Create bars and choose color
            plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))

            # Add title and axis names
            plt.title('QUYỀN QUYẾT ĐỊNH SỬ DỤNG THU NHẬP GIA ĐÌNH')
            plt.xlabel('TB_QQD_x_2')
            plt.ylabel('Số lượng')

            # Create names on the x axis
            plt.xticks(x_pos, bars)
        elif namechart == 'charts-4':
            # create dataset
            height = [0, 0, 0, 0, 0]
            bars = ('1', '2', '3', '4', '5')
            for item in export_data:
                if item[4] <= 1:
                    height[0] = height[0] + 1
                elif item[4] <= 2:
                    height[1] = height[1] + 1
                elif item[4] <= 3:
                    height[2] = height[2] + 1
                elif item[4] <= 4:
                    height[3] = height[3] + 1
                elif item[4] <= 5:
                    height[4] = height[4] + 1

            x_pos = np.arange(len(bars))

            # Create bars and choose color
            plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))

            # Add title and axis names
            plt.title('TRUNG BÌNH BIẾN SỐ THAM GIA XÃ HỘI')
            plt.xlabel('TB_XH')
            plt.ylabel('Số lượng')

            # Create names on the x axis
            plt.xticks(x_pos, bars)
        elif namechart == 'charts-5':
            # create dataset
            height = [0, 0, 0, 0, 0]
            bars = ('1', '2', '3', '4', '5')
            for item in export_data:
                if item[5] <= 1:
                    height[0] = height[0] + 1
                elif item[5] <= 2:
                    height[1] = height[1] + 1
                elif item[5] <= 3:
                    height[2] = height[2] + 1
                elif item[5] <= 4:
                    height[3] = height[3] + 1
                elif item[5] <= 5:
                    height[4] = height[4] + 1

            x_pos = np.arange(len(bars))

            # Create bars and choose color
            plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))

            # Add title and axis names
            plt.title('TRUNG BÌNH BIẾN SỐ SD THỜI GIAN')
            plt.xlabel('TB_TG')
            plt.ylabel('Số lượng')

            # Create names on the x axis
            plt.xticks(x_pos, bars)
        elif namechart == 'charts-6':
            # create dataset
            height = [0, 0, 0, 0, 0]
            bars = ('1', '2', '3', '4', '5')
            for item in export_data:
                if item[6] <= 1:
                    height[0] = height[0] + 1
                elif item[6] <= 2:
                    height[1] = height[1] + 1
                elif item[6] <= 3:
                    height[2] = height[2] + 1
                elif item[6] <= 4:
                    height[3] = height[3] + 1
                elif item[6] <= 5:
                    height[4] = height[4] + 1

            x_pos = np.arange(len(bars))

            # Create bars and choose color
            plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))

            # Add title and axis names
            plt.title('TRUNG BÌNH TRAO QUYỀN CUỐI CÙNG')
            plt.xlabel('TB_TBC')
            plt.ylabel('Số lượng')

            # Create names on the x axis
            plt.xticks(x_pos, bars)
        elif namechart == 'charts-7':
            # create dataset
            height = [0, 0, 0, 0, 0,0,0,0,0,0,0]
            bars = ('1', '2', '3', '4', '5','6', '7', '8', '9', '10','11')
            for item in export_data:
                if item[7] <= 1:
                    height[0] = height[0] + 1
                elif item[7] <= 2:
                    height[1] = height[1] + 1
                elif item[7] <= 3:
                    height[2] = height[2] + 1
                elif item[7] <= 4:
                    height[3] = height[3] + 1
                elif item[7] <= 5:
                    height[4] = height[4] + 1
                elif item[7] <= 6:
                    height[5] = height[5] + 1
                elif item[7] <= 7:
                    height[6] = height[6] + 1
                elif item[7] <= 8:
                    height[7] = height[7] + 1
                elif item[7] <= 9:
                    height[8] = height[8] + 1
                elif item[7] <= 10:
                    height[9] = height[9] + 1
                elif item[7] <= 11:
                    height[10] = height[10] + 1
            x_pos = np.arange(len(bars))

            # Create bars and choose color
            plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))

            # Add title and axis names
            plt.title('TRUNG BÌNH TRAO QUYỀN CUỐI CÙNG (HS NHÂN ĐÔI)')
            plt.xlabel('TB_TBC_X_2')
            plt.ylabel('Số lượng')

            # Create names on the x axis
            plt.xticks(x_pos, bars)
        elif namechart == 'charts-8':
            plt.rcParams["figure.figsize"] = (20, 5)
            # create random data
            names = 'Không trao quyền', 'Được trao quyền'
            values = [0, 0]
            for item in export_data:
                if item[8] == 0:
                    values[0]=values[0]+1
                elif item[8] == 1:
                    values[1] = values[1] + 1
            # Create a pieplot
            plt.pie(values,labels=names,autopct='%.2f');

        flike = io.BytesIO()
        plt.savefig(flike)
        b64 = base64.b64encode(flike.getvalue()).decode()

        context = {
            'namechart': namechart,
            'charts': b64
        }

        return render(request, 'homepage/computing-charts.html', context)


class IndependentChartsView(LoginRequiredMixin, View):
    # def get(self, request):
    #     print(request.user.username)
    #     qb = 'manager_qb'
    #     qn = 'manager_qn'
    #     username = request.user.username
    #     logging.basicConfig(level=logging.INFO)
    #     logging.debug("Log message goes here.")
    #     data = Survey.objects.all()
    #
    #     if (username == qb):
    #         print('user 44')
    #         data = Survey_44.objects.all()
    #     else:
    #         if (username == qn):
    #             print('user51')
    #             data = Survey_51.objects.all()

    def post(self, request):
        post = request.POST
        bien = post.get('bien', None),
        style = post.get('style', None)
        print(bien[0])
        print(style)
        print(request.user.username)
        qb = 'manager_qb'
        qn = 'manager_qn'
        username = request.user.username
        logging.basicConfig(level=logging.INFO)
        # logging.debug("Log message goes here.")
        data = Survey.objects.all()
        # data = Survey_44.objects.all()
        if (username == qb):
            print('user 44')
            data = Survey_44.objects.all()
        else:
            if (username == qn):
                print('user51')
                data = Survey_51.objects.all()

        # data
        index2 = [1, 2]
        index3 = [1, 2, 3]
        index4 = [1, 2, 3, 4]
        index5 = [1, 2, 3, 4, 5]
        index6 = [1, 2, 3, 4, 5, 6]
        index7 = [1, 2, 3, 4, 5, 6, 7]
        index8 = [1, 2, 3, 4, 5, 6, 7, 8]
        for item in data:
            item.area = converttonumber(item.area, index4, 'area')
            item.nation = converttonumber(item.nation, index2, 'nation')
            item.gender = converttonumber(item.gender, index3, 'gender')
            item.age = converttonumber(item.age, index5, 'age')
            item.education = converttonumber(item.education, index7, 'education')
            item.children = converttonumber(item.children, index7, 'children')
            item.children_education = converttonumber(item.children_education, index8, 'children_education')
            item.distance = converttonumber(item.distance, index7, 'distance')
            item.people = converttonumber(item.people, index7, 'people')
            item.income = converttonumber(item.income, index5, 'income')
            item.footcrops1 = converttonumber(item.footcrops1, index5, 'footcrops1')
            item.footcrops2 = converttonumber(item.footcrops2, index5, 'footcrops2')
            item.treecommercial1 = converttonumber(item.treecommercial1, index5, 'treecommercial1')
            item.treecommercial2 = converttonumber(item.treecommercial2, index5, 'treecommercial2')
            item.breed1 = converttonumber(item.breed1, index5, 'breed1')
            item.breed2 = converttonumber(item.breed2, index5, 'breed2')
            item.employed1 = converttonumber(item.employed1, index5, 'employed1')
            item.employed2 = converttonumber(item.employed2, index5, 'employed2')
            item.spending1 = converttonumber(item.spending1, index5, 'spending1')
            item.spending2 = converttonumber(item.spending2, index5, 'spending2')
            item.ordinaryspending1 = converttonumber(item.ordinaryspending1, index5, 'ordinaryspending1')
            item.ordinaryspending2 = converttonumber(item.ordinaryspending2, index5, 'ordinaryspending2')
            item.agriculturalland1 = converttonumber(item.agriculturalland1, index5, 'agriculturalland1')
            item.agriculturalland2 = converttonumber(item.agriculturalland2, index5, 'agriculturalland2')
            item.bigpets1 = converttonumber(item.bigpets1, index5, 'bigpets1')
            item.bigpets2 = converttonumber(item.bigpets2, index5, 'bigpets2')
            item.average1 = converttonumber(item.average1, index5, 'average1')
            item.average2 = converttonumber(item.average2, index5, 'average2')
            item.smallpets1 = converttonumber(item.smallpets1, index5, 'smallpets1')
            item.smallpets2 = converttonumber(item.smallpets2, index5, 'smallpets2')
            item.fishpond1 = converttonumber(item.fishpond1, index5, 'fishpond1')
            item.fishpond2 = converttonumber(item.fishpond2, index5, 'fishpond2')
            item.agriculturaltools1 = converttonumber(item.agriculturaltools1, index5, 'agriculturaltools1')
            item.agriculturaltools2 = converttonumber(item.agriculturaltools2, index5, 'agriculturaltools2')
            item.machines1 = converttonumber(item.machines1, index5, 'machines1')
            item.machines2 = converttonumber(item.machines2, index5, 'machines2')
            # llllllllll
            item.device1 = converttonumber(item.device1, index5, 'device1')
            item.device2 = converttonumber(item.device2, index5, 'device2')
            item.home1 = converttonumber(item.home1, index5, 'home1')
            item.home2 = converttonumber(item.home2, index5, 'home2')
            item.belongings1 = converttonumber(item.belongings1, index5, 'belongings1')
            item.belongings2 = converttonumber(item.belongings2, index5, 'belongings2')
            item.smallbelongings1 = converttonumber(item.smallbelongings1, index5, 'smallbelongings1')
            item.smallbelongings2 = converttonumber(item.smallbelongings2, index5, 'smallbelongings2')
            item.phone1 = converttonumber(item.phone1, index5, 'phone1')
            item.phone2 = converttonumber(item.phone2, index5, 'phone2')
            item.nonagricultural1 = converttonumber(item.nonagricultural1, index5, 'nonagricultural1')
            item.nonagricultural2 = converttonumber(item.nonagricultural2, index5, 'nonagricultural2')
            item.vehicle1 = converttonumber(item.vehicle1, index5, 'vehicle1')
            item.vehicle2 = converttonumber(item.vehicle2, index5, 'vehicle2')
            # # llllll
            item.nongovernmental1 = converttonumber(item.nongovernmental1, index5, 'nongovernmental1')
            item.nongovernmental2 = converttonumber(item.nongovernmental2, index5, 'nongovernmental2')
            item.official1 = converttonumber(item.official1, index5, 'official1')
            item.official2 = converttonumber(item.official2, index5, 'official2')
            item.friend1 = converttonumber(item.friend1, index5, 'friend1')
            item.friend2 = converttonumber(item.friend2, index5, 'friend2')
            item.spendingfamily = converttonumber(item.spendingfamily, index5, 'spendingfamily')
            # # ppppppppp4
            item.trade1 = converttonumber(item.trade1, index5, 'trade1')
            item.trade2 = converttonumber(item.trade2, index6, 'trade2')
            item.forestry1 = converttonumber(item.forestry1, index5, 'forestry1')
            item.forestry2 = converttonumber(item.forestry2, index6, 'forestry2')
            item.finance1 = converttonumber(item.finance1, index5, 'finance1')
            item.finance2 = converttonumber(item.finance2, index6, 'finance2')
            item.insurance1 = converttonumber(item.insurance1, index5, 'insurance1')
            item.insurance2 = converttonumber(item.insurance2, index6, 'insurance2')
            item.business1 = converttonumber(item.business1, index5, 'business1')
            item.business2 = converttonumber(item.business2, index6, 'business2')
            item.charity1 = converttonumber(item.charity1, index5, 'charity1')
            item.charity2 = converttonumber(item.charity2, index6, 'charity2')
            item.religion1 = converttonumber(item.religion1, index5, 'religion1')
            item.religion2 = converttonumber(item.religion2, index6, 'religion2')
            item.work = converttonumber(item.work, index5, 'work')
            item.workof = converttonumber(item.workof, index5, 'workof')

        export_data = []

        plt.clf()
        # value = "1" > Bar
        # value = "2" > Line
        # value = "3" > Pie
        # value = "4" > Box
        # value = "5" > Scater
        if style == 1 or style == '1':
            if bien[0] == 'dan_toc':
                # create dataset
                height = [0, 0]
                bars = ('Dân tộc Kinh', 'Dân tộc khác')
                for item in data:
                    print('kkkkk')
                    if item.nation == 1:
                        height[0] = height[0]+1
                    elif item.nation == 2:
                        height[1] = height[1] + 1
                x_pos = np.arange(len(bars))

                # Create bars and choose color
                plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))

                # Add title and axis names
                plt.title('Dân tộc')
                plt.xlabel('Dân tộc')
                plt.ylabel('Số lượng')

                # Create names on the x axis
                plt.xticks(x_pos, bars)

            elif bien[0] == 'hoc_van':
                # create dataset
                height = [0, 0, 0, 0, 0, 0, 0]
                # bars = ('Chưa đi học', 'Tiểu học', "THCS", "THPT", "Cao Đẳng", "Đại học", "Sau đại học")
                bars = ('1', '2', "3", "4", "5", "6", "7")
                for item in data:
                    # print('kkkkk')
                    if item.education == 1:
                        height[0] = height[0]+1
                    elif item.education == 2:
                        height[1] = height[1] + 1
                    elif item.education == 3:
                        height[2] = height[2] + 1
                    elif item.education == 4:
                        height[3] = height[3] + 1
                    elif item.education == 5:
                        height[4] = height[4] + 1
                    elif item.education == 6:
                        height[5] = height[5] + 1
                    elif item.education == 7:
                        height[6] = height[6] + 1
                x_pos = np.arange(len(bars))

                # Create bars and choose color
                plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))

                # Add title and axis names
                plt.title('Học vấn')
                plt.xlabel('Học vấn')
                plt.ylabel('Số lượng')

                # Create names on the x axis
                plt.xticks(x_pos, bars)
            elif bien[0] == 'gioi_tinh':
                height = [0, 0, 0]
                bars = ('Nam', 'Nữ', "Khác")
                for item in data:
                    if item.gender == 1:
                        height[0] = height[0] + 1
                    elif item.gender == 2:
                        height[1] = height[1] + 1
                    elif item.gender == 3:
                        height[2] = height[2] + 1
                x_pos = np.arange(len(bars))

                # Create bars and choose color
                plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))
                # Add title and axis names
                plt.title('Giới tính')
                plt.xlabel('Giới tính')
                plt.ylabel('Số lượng')

                # Create names on the x axis
                plt.xticks(x_pos, bars)
            elif bien[0] == 'hoc_van_con':
                # create dataset
                height = [0, 0, 0, 0, 0, 0, 0]
                # bars = ('Chưa đi học', 'Tiểu học', "THCS", "THPT", "Cao Đẳng", "Đại học", "Sau đại học")
                bars = ('1', '2', "3", "4", "5", "6", "7")
                for item in data:
                    if item.children_education == 1:
                        height[0] = height[0] + 1
                    elif item.children_education == 2:
                        height[1] = height[1] + 1
                    elif item.children_education == 3:
                        height[2] = height[2] + 1
                    elif item.children_education == 4:
                        height[3] = height[3] + 1
                    elif item.children_education == 5:
                        height[4] = height[4] + 1
                    elif item.children_education == 6:
                        height[5] = height[5] + 1
                    elif item.children_education == 7:
                        height[6] = height[6] + 1
                x_pos = np.arange(len(bars))
                # Create bars and choose color
                plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))
                # Add title and axis names
                plt.title('Học vấn cao nhất của con')
                plt.xlabel('Học vấn cao nhất của con')
                plt.ylabel('Số lượng')
                # Create names on the x axis
                plt.xticks(x_pos, bars)
            elif bien[0] == 'khoang_cach':
                # create dataset
                height = [0, 0, 0, 0, 0, 0, 0]
                # bars = ("Khoảng 1 km", "Khoảng từ 1-2 km", "Khoảng từ 2-3 km", "Khoảng từ 3-4 km", "Khoảng từ 4-5 km",
                #         "Khoảng từ 5-7 km", "Nhiều hơn 7 km")
                bars = ('1', '2', "3", "4", "5", "6", "7")
                for item in data:
                    if item.distance == 1:
                        height[0] = height[0] + 1
                    elif item.distance == 2:
                        height[1] = height[1] + 1
                    elif item.distance == 3:
                        height[2] = height[2] + 1
                    elif item.distance == 4:
                        height[3] = height[3] + 1
                    elif item.distance == 5:
                        height[4] = height[4] + 1
                    elif item.distance == 6:
                        height[5] = height[5] + 1
                    elif item.distance == 7:
                        height[6] = height[6] + 1
                x_pos = np.arange(len(bars))
                # Create bars and choose color
                plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))
                # Add title and axis names
                plt.title('Khoảng cách đến đô thị')
                plt.xlabel('Khoảng cách đến đô thị')
                plt.ylabel('Số lượng')
                # Create names on the x axis
                plt.xticks(x_pos, bars)
            elif bien[0] == 'so_nhan_khau':
                # create dataset
                height = [0, 0, 0, 0, 0, 0, 0]
                # bars = ("1 nhân khẩu", "2 nhân khẩu", "3 nhân khẩu", "4 nhân khẩu", "5 nhân khẩu",
                #         "6 nhân khẩu", "Nhiều hơn 6 nhân khẩu")
                bars = ('1', '2', "3", "4", "5", "6", "7")
                for item in data:
                    if item.people == 1:
                        height[0] = height[0] + 1
                    elif item.people == 2:
                        height[1] = height[1] + 1
                    elif item.people == 3:
                        height[2] = height[2] + 1
                    elif item.people == 4:
                        height[3] = height[3] + 1
                    elif item.people == 5:
                        height[4] = height[4] + 1
                    elif item.people == 6:
                        height[5] = height[5] + 1
                    elif item.people == 7:
                        height[6] = height[6] + 1
                x_pos = np.arange(len(bars))
                # Create bars and choose color
                plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))
                # Add title and axis names
                plt.title('số nhân khẩu trong hộ dân')
                plt.xlabel('số nhân khẩu trong hộ dân')
                plt.ylabel('Số lượng')
                # Create names on the x axis
                plt.xticks(x_pos, bars)
            elif bien[0] == 'tong_thu_nhap':
                # create dataset
                height = [0, 0, 0, 0, 0]
                # bars = ("Dưới 3 triệu", "Từ 3 đến 5 triệu", "Từ 5 đến 7 triệu", "Từ 7 đến 10 triệu", "Trên 10 triệu")
                bars = ('1', '2', "3", "4", "5")
                for item in data:
                    if item.income == 1:
                        height[0] = height[0] + 1
                    elif item.income == 2:
                        height[1] = height[1] + 1
                    elif item.income == 3:
                        height[2] = height[2] + 1
                    elif item.income == 4:
                        height[3] = height[3] + 1
                    elif item.income == 5:
                        height[4] = height[4] + 1
                x_pos = np.arange(len(bars))
                # Create bars and choose color
                plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))
                # Add title and axis names
                plt.title('Thu nhập hộ gia đình/tháng')
                plt.xlabel('Thu nhập hộ gia đình/tháng')
                plt.ylabel('Số lượng')
                # Create names on the x axis
                plt.xticks(x_pos, bars)

            elif bien[0] == 'tuoi':
                # create dataset
                height = [0, 0, 0, 0, 0]
                # bars = ("18-24 tuổi", "25-30 tuổi", "31-36 tuổi", "37-42 tuổi", "43-50 tuổi")
                bars = ('1', '2', "3", "4", "5")
                for item in data:
                    if item.age == 1:
                        height[0] = height[0] + 1
                    elif item.age == 2:
                        height[1] = height[1] + 1
                    elif item.age == 3:
                        height[2] = height[2] + 1
                    elif item.age == 4:
                        height[3] = height[3] + 1
                    elif item.age == 5:
                        height[4] = height[4] + 1
                x_pos = np.arange(len(bars))
                # Create bars and choose color
                plt.bar(x_pos, height, color=(0.5, 0.1, 0.5, 0.6))
                # Add title and axis names
                plt.title('Độ tuổi')
                plt.xlabel('Độ tuổi')
                plt.ylabel('Số lượng')
                # Create names on the x axis
                plt.xticks(x_pos, bars)
        elif style == "2":
            # data
            df = pd.DataFrame({
                'x_axis': range(1, 10),
                'y_axis': np.random.randn(9) * 80 + range(1, 10)
            })

            # plot
            fig = plt.figure(figsize=(8, 8))
            plt.plot('x_axis', 'y_axis', data=df, linestyle='-', marker='o')
        elif style == "3":
            if bien[0] == 'dan_toc':
                plt.rcParams["figure.figsize"] = (20, 5)
                # create random data
                names = 'Dân tộc kinh', 'Dân tộc khác'
                values = [0, 0]
                for item in data:
                    if item.nation == 1:
                        values[0] = values[0] + 1
                    elif item.nation == 2:
                        values[1] = values[1] + 1
                # Create a pieplot
                plt.pie(values, labels=names, autopct='%.2f')

            elif bien[0] == 'hoc_van':
                plt.rcParams["figure.figsize"] = (20, 5)
                # create random data
                names = 'Chưa đi học', 'Tiểu học', "THCS", "THPT", "Cao Đẳng", "Đại học", "Sau đại học"
                values = [0, 0, 0, 0, 0, 0, 0]
                for item in data:
                    if item.education == 1:
                        values[0] = values[0] + 1
                    elif item.education == 2:
                        values[1] = values[1] + 1
                    elif item.education == 3:
                        values[2] = values[2] + 1
                    elif item.education == 4:
                        values[3] = values[3] + 1
                    elif item.education == 5:
                        values[4] = values[4] + 1
                    elif item.education == 6:
                        values[5] = values[5] + 1
                    elif item.education == 7:
                        values[6] = values[6] + 1
                # Create a pieplot
                plt.pie(values, labels=names, autopct='%.2f')
            elif bien[0] == 'gioi_tinh':
                plt.rcParams["figure.figsize"] = (20, 5)
                # create random data
                names = 'Nam', 'Nữ', 'Khác'
                values = [0, 0, 0]
                for item in data:
                    if item.gender == 1:
                        values[0] = values[0] + 1
                    elif item.gender == 2:
                        values[1] = values[1] + 1
                    elif item.gender == 3:
                        values[2] = values[2] + 1
                # Create a pieplot
                plt.pie(values, labels=names, autopct='%.2f')

            elif bien[0] == 'hoc_van_con':
                plt.rcParams["figure.figsize"] = (20, 5)
                # create random data
                names = 'Chưa đi học', 'Tiểu học', "THCS", "THPT", "Cao Đẳng", "Đại học", "Sau đại học"
                values = [0, 0, 0, 0, 0, 0, 0]
                for item in data:
                    if item.children_education == 1:
                        values[0] = values[0] + 1
                    elif item.children_education == 2:
                        values[1] = values[1] + 1
                    elif item.children_education == 3:
                        values[2] = values[2] + 1
                    elif item.children_education == 4:
                        values[3] = values[3] + 1
                    elif item.children_education == 5:
                        values[4] = values[4] + 1
                    elif item.children_education == 6:
                        values[5] = values[5] + 1
                    elif item.children_education == 7:
                        values[6] = values[6] + 1
                # Create a pieplot
                plt.pie(values, labels=names, autopct='%.2f')

            elif bien[0] == 'khoang_cach':
                plt.rcParams["figure.figsize"] = (20, 5)
                # create random data
                names = "Khoảng 1 km", "Khoảng từ 1-2 km", "Khoảng từ 2-3 km", "Khoảng từ 3-4 km", "Khoảng từ 4-5 km", \
                        "Khoảng từ 5-7 km", "Nhiều hơn 7 km"
                values = [0, 0, 0, 0, 0, 0, 0]
                for item in data:
                    if item.distance == 1:
                        values[0] = values[0] + 1
                    elif item.distance == 2:
                        values[1] = values[1] + 1
                    elif item.distance == 3:
                        values[2] = values[2] + 1
                    elif item.distance == 4:
                        values[3] = values[3] + 1
                    elif item.distance == 5:
                        values[4] = values[4] + 1
                    elif item.distance == 6:
                        values[5] = values[5] + 1
                    elif item.distance == 7:
                        values[6] = values[6] + 1
                # Create a pieplot
                plt.pie(values, labels=names, autopct='%.2f')
            elif bien[0] == 'so_nhan_khau':
                plt.rcParams["figure.figsize"] = (20, 5)
                # create random data
                names = "1 nhân khẩu", "2 nhân khẩu", "3 nhân khẩu", "4 nhân khẩu", "5 nhân khẩu", \
                        "6 nhân khẩu", "Nhiều hơn 6 nhân khẩu"
                values = [0, 0, 0, 0, 0, 0, 0]
                for item in data:
                    if item.people == 1:
                        values[0] = values[0] + 1
                    elif item.people == 2:
                        values[1] = values[1] + 1
                    elif item.people == 3:
                        values[2] = values[2] + 1
                    elif item.people == 4:
                        values[3] = values[3] + 1
                    elif item.people == 5:
                        values[4] = values[4] + 1
                    elif item.people == 6:
                        values[5] = values[5] + 1
                    elif item.people == 7:
                        values[6] = values[6] + 1
                # Create a pieplot
                plt.pie(values, labels=names, autopct='%.2f')
            elif bien[0] == 'tong_thu_nhap':
                plt.rcParams["figure.figsize"] = (20, 5)
                # create random data
                names = "Dưới 3 triệu", "Từ 3 đến 5 triệu", "Từ 5 đến 7 triệu", "Từ 7 đến 10 triệu", "Trên 10 triệu"
                values = [0, 0, 0, 0, 0]
                for item in data:
                    if item.income == 1:
                        values[0] = values[0] + 1
                    elif item.income == 2:
                        values[1] = values[1] + 1
                    elif item.income == 3:
                        values[2] = values[2] + 1
                    elif item.income == 4:
                        values[3] = values[3] + 1
                    elif item.income == 5:
                        values[4] = values[4] + 1
                # Create a pieplot
                plt.pie(values, labels=names, autopct='%.2f')
            elif bien[0] == 'tuoi':
                plt.rcParams["figure.figsize"] = (20, 5)
                # create random data
                names = "18-24 tuổi", "25-30 tuổi", "31-36 tuổi", "37-42 tuổi", "43-50 tuổi"
                values = [0, 0, 0, 0, 0]
                for item in data:
                    if item.age == 1:
                        values[0] = values[0] + 1
                    elif item.age == 2:
                        values[1] = values[1] + 1
                    elif item.age == 3:
                        values[2] = values[2] + 1
                    elif item.age == 4:
                        values[3] = values[3] + 1
                    elif item.age == 5:
                        values[4] = values[4] + 1
                # Create a pieplot
                plt.pie(values, labels=names, autopct='%.2f')

        elif style == "5":
            # library & dataset
            import seaborn as sns
            df = sns.load_dataset('iris')

            # use the function regplot to make a scatterplot
            sns.regplot(x=df["sepal_length"], y=df["sepal_width"])
        elif style == "4":
            import seaborn as sns
            sns.set(style="darkgrid")
            df = sns.load_dataset('iris')

            # Usual boxplot
            ax = sns.boxplot(x='species', y='sepal_length', data=df)

            # Add jitter with the swarmplot function
            ax = sns.swarmplot(x='species', y='sepal_length', data=df, color="grey")

        flike = io.BytesIO()
        plt.savefig(flike)
        b64 = base64.b64encode(flike.getvalue()).decode()

        context = {
            'charts': b64
        }

        return render(request, 'homepage/independent-charts.html', context)


class IndependentVarView(LoginRequiredMixin, View):
    login_url = '/login-views/'
    def get(self, request):
        return render(request, 'homepage/independent-var.html')


class SubmitView(View):
    def post(self, request):
        payload = request.POST
        try:
            survey = Survey(
                province=payload.get('province', None),
                district=payload.get('district', None),
                ward=payload.get('ward', None),
                education=payload.get('education', None),
                area=payload.get('area', None),
                gender=payload.get('gender', None),
                nation=payload.get('nation', None),
                age=payload.get('age', None),
                children=payload.get('children', None),
                children_education=payload.get('children_education', None),
                distance=payload.get('distance', None),
                people=payload.get('people', None),
                income=payload.get('income', None),
                footcrops1=payload.get('footcrops1', None),
                footcrops2=payload.get('footcrops2', None),
                treecommercial1=payload.get('treecommercial1', None),
                treecommercial2=payload.get('treecommercial2', None),
                breed1=payload.get('breed1', None),
                breed2=payload.get('breed2', None),
                employed1=payload.get('employed1', None),
                employed2=payload.get('employed2', None),
                spending1=payload.get('spending1', None),
                spending2=payload.get('spending2', None),
                ordinaryspending1=payload.get('ordinaryspending1', None),
                ordinaryspending2=payload.get('ordinaryspending2', None),
                agriculturalland1=payload.get('agriculturalland1', None),
                agriculturalland2=payload.get('agriculturalland2', None),
                bigpets1=payload.get('bigpets1', None),
                bigpets2=payload.get('bigpets2', None),
                average1=payload.get('average1', None),
                average2=payload.get('average2', None),
                smallpets1=payload.get('smallpets1', None),
                smallpets2=payload.get('smallpets2', None),
                fishpond1=payload.get('fishpond1', None),
                fishpond2=payload.get('fishpond2', None),
                agriculturaltools1=payload.get('agriculturaltools1', None),
                agriculturaltools2=payload.get('agriculturaltools2', None),
                machines1=payload.get('machines1', None),
                machines2=payload.get('machines2', None),
                device1=payload.get('device1', None),
                device2=payload.get('device2', None),
                home1=payload.get('home1', None),
                home2=payload.get('home2', None),
                belongings1=payload.get('belongings1', None),
                belongings2=payload.get('belongings2', None),
                smallbelongings1=payload.get('smallbelongings1', None),
                smallbelongings2=payload.get('smallbelongings2', None),
                phone1=payload.get('phone1', None),
                phone2=payload.get('phone2', None),
                nonagricultural1=payload.get('nonagricultural1', None),
                nonagricultural2=payload.get('nonagricultural2', None),
                # cc
                vehicle1=payload.get('vehicle1', None),
                vehicle2=payload.get('vehicle2', None),
                nongovernmental1=payload.get('nongovernmental1', None),
                nongovernmental2=payload.get('nongovernmental2', None),
                official1=payload.get('official1', None),
                official2=payload.get('official2', None),
                friend1=payload.get('friend1', None),
                friend2=payload.get('friend2', None),
                spendingfamily=payload.get('spendingfamily', None),
                trade1=payload.get('trade1', None),
                trade2=payload.get('trade2', None),
                forestry1=payload.get('forestry1', None),
                forestry2=payload.get('forestry2', None),
                finance1=payload.get('finance1', None),
                finance2=payload.get('finance2', None),
                insurance1=payload.get('insurance1', None),
                insurance2=payload.get('insurance2', None),
                business1=payload.get('business1', None),
                business2=payload.get('business2', None),
                charity1=payload.get('charity1', None),
                charity2=payload.get('charity2', None),
                religion1=payload.get('religion1', None),
                religion2=payload.get('religion2', None),
                work=payload.get('work', None),
                workof=payload.get('workof', None),
            )
            survey.save()
            province = payload.get('province', None)
            if (province == '44'):
                survey_44 = Survey_44(
                    province=payload.get('province', None),
                    district=payload.get('district', None),
                    ward=payload.get('ward', None),
                    education=payload.get('education', None),
                    area=payload.get('area', None),
                    gender=payload.get('gender', None),
                    nation=payload.get('nation', None),
                    age=payload.get('age', None),
                    children=payload.get('children', None),
                    children_education=payload.get('children_education', None),
                    distance=payload.get('distance', None),
                    people=payload.get('people', None),
                    income=payload.get('income', None),
                    footcrops1=payload.get('footcrops1', None),
                    footcrops2=payload.get('footcrops2', None),
                    treecommercial1=payload.get('treecommercial1', None),
                    treecommercial2=payload.get('treecommercial2', None),
                    breed1=payload.get('breed1', None),
                    breed2=payload.get('breed2', None),
                    employed1=payload.get('employed1', None),
                    employed2=payload.get('employed2', None),
                    spending1=payload.get('spending1', None),
                    spending2=payload.get('spending2', None),
                    ordinaryspending1=payload.get('ordinaryspending1', None),
                    ordinaryspending2=payload.get('ordinaryspending2', None),
                    agriculturalland1=payload.get('agriculturalland1', None),
                    agriculturalland2=payload.get('agriculturalland2', None),
                    bigpets1=payload.get('bigpets1', None),
                    bigpets2=payload.get('bigpets2', None),
                    average1=payload.get('average1', None),
                    average2=payload.get('average2', None),
                    smallpets1=payload.get('smallpets1', None),
                    smallpets2=payload.get('smallpets2', None),
                    fishpond1=payload.get('fishpond1', None),
                    fishpond2=payload.get('fishpond2', None),
                    agriculturaltools1=payload.get('agriculturaltools1', None),
                    agriculturaltools2=payload.get('agriculturaltools2', None),
                    machines1=payload.get('machines1', None),
                    machines2=payload.get('machines2', None),
                    device1=payload.get('device1', None),
                    device2=payload.get('device2', None),
                    home1=payload.get('home1', None),
                    home2=payload.get('home2', None),
                    belongings1=payload.get('belongings1', None),
                    belongings2=payload.get('belongings2', None),
                    smallbelongings1=payload.get('smallbelongings1', None),
                    smallbelongings2=payload.get('smallbelongings2', None),
                    phone1=payload.get('phone1', None),
                    phone2=payload.get('phone2', None),
                    nonagricultural1=payload.get('nonagricultural1', None),
                    nonagricultural2=payload.get('nonagricultural2', None),
                    # cc
                    vehicle1=payload.get('vehicle1', None),
                    vehicle2=payload.get('vehicle2', None),
                    nongovernmental1=payload.get('nongovernmental1', None),
                    nongovernmental2=payload.get('nongovernmental2', None),
                    official1=payload.get('official1', None),
                    official2=payload.get('official2', None),
                    friend1=payload.get('friend1', None),
                    friend2=payload.get('friend2', None),
                    spendingfamily=payload.get('spendingfamily', None),
                    trade1=payload.get('trade1', None),
                    trade2=payload.get('trade2', None),
                    forestry1=payload.get('forestry1', None),
                    forestry2=payload.get('forestry2', None),
                    finance1=payload.get('finance1', None),
                    finance2=payload.get('finance2', None),
                    insurance1=payload.get('insurance1', None),
                    insurance2=payload.get('insurance2', None),
                    business1=payload.get('business1', None),
                    business2=payload.get('business2', None),
                    charity1=payload.get('charity1', None),
                    charity2=payload.get('charity2', None),
                    religion1=payload.get('religion1', None),
                    religion2=payload.get('religion2', None),
                    work=payload.get('work', None),
                    workof=payload.get('workof', None),
                )
                survey_44.save()
            if (province == '49'):
                survey_49 = Survey_49(
                    province=payload.get('province', None),
                    district=payload.get('district', None),
                    ward=payload.get('ward', None),
                    education=payload.get('education', None),
                    area=payload.get('area', None),
                    gender=payload.get('gender', None),
                    nation=payload.get('nation', None),
                    age=payload.get('age', None),
                    children=payload.get('children', None),
                    children_education=payload.get('children_education', None),
                    distance=payload.get('distance', None),
                    people=payload.get('people', None),
                    income=payload.get('income', None),
                    footcrops1=payload.get('footcrops1', None),
                    footcrops2=payload.get('footcrops2', None),
                    treecommercial1=payload.get('treecommercial1', None),
                    treecommercial2=payload.get('treecommercial2', None),
                    breed1=payload.get('breed1', None),
                    breed2=payload.get('breed2', None),
                    employed1=payload.get('employed1', None),
                    employed2=payload.get('employed2', None),
                    spending1=payload.get('spending1', None),
                    spending2=payload.get('spending2', None),
                    ordinaryspending1=payload.get('ordinaryspending1', None),
                    ordinaryspending2=payload.get('ordinaryspending2', None),
                    agriculturalland1=payload.get('agriculturalland1', None),
                    agriculturalland2=payload.get('agriculturalland2', None),
                    bigpets1=payload.get('bigpets1', None),
                    bigpets2=payload.get('bigpets2', None),
                    average1=payload.get('average1', None),
                    average2=payload.get('average2', None),
                    smallpets1=payload.get('smallpets1', None),
                    smallpets2=payload.get('smallpets2', None),
                    fishpond1=payload.get('fishpond1', None),
                    fishpond2=payload.get('fishpond2', None),
                    agriculturaltools1=payload.get('agriculturaltools1', None),
                    agriculturaltools2=payload.get('agriculturaltools2', None),
                    machines1=payload.get('machines1', None),
                    machines2=payload.get('machines2', None),
                    device1=payload.get('device1', None),
                    device2=payload.get('device2', None),
                    home1=payload.get('home1', None),
                    home2=payload.get('home2', None),
                    belongings1=payload.get('belongings1', None),
                    belongings2=payload.get('belongings2', None),
                    smallbelongings1=payload.get('smallbelongings1', None),
                    smallbelongings2=payload.get('smallbelongings2', None),
                    phone1=payload.get('phone1', None),
                    phone2=payload.get('phone2', None),
                    nonagricultural1=payload.get('nonagricultural1', None),
                    nonagricultural2=payload.get('nonagricultural2', None),
                    # cc
                    vehicle1=payload.get('vehicle1', None),
                    vehicle2=payload.get('vehicle2', None),
                    nongovernmental1=payload.get('nongovernmental1', None),
                    nongovernmental2=payload.get('nongovernmental2', None),
                    official1=payload.get('official1', None),
                    official2=payload.get('official2', None),
                    friend1=payload.get('friend1', None),
                    friend2=payload.get('friend2', None),
                    spendingfamily=payload.get('spendingfamily', None),
                    trade1=payload.get('trade1', None),
                    trade2=payload.get('trade2', None),
                    forestry1=payload.get('forestry1', None),
                    forestry2=payload.get('forestry2', None),
                    finance1=payload.get('finance1', None),
                    finance2=payload.get('finance2', None),
                    insurance1=payload.get('insurance1', None),
                    insurance2=payload.get('insurance2', None),
                    business1=payload.get('business1', None),
                    business2=payload.get('business2', None),
                    charity1=payload.get('charity1', None),
                    charity2=payload.get('charity2', None),
                    religion1=payload.get('religion1', None),
                    religion2=payload.get('religion2', None),
                    work=payload.get('work', None),
                    workof=payload.get('workof', None),
                )
                survey_49.save()

            if (province == '51'):
                survey_51 = Survey_51(
                    province=payload.get('province', None),
                    district=payload.get('district', None),
                    ward=payload.get('ward', None),
                    education=payload.get('education', None),
                    area=payload.get('area', None),
                    gender=payload.get('gender', None),
                    nation=payload.get('nation', None),
                    age=payload.get('age', None),
                    children=payload.get('children', None),
                    children_education=payload.get('children_education', None),
                    distance=payload.get('distance', None),
                    people=payload.get('people', None),
                    income=payload.get('income', None),
                    footcrops1=payload.get('footcrops1', None),
                    footcrops2=payload.get('footcrops2', None),
                    treecommercial1=payload.get('treecommercial1', None),
                    treecommercial2=payload.get('treecommercial2', None),
                    breed1=payload.get('breed1', None),
                    breed2=payload.get('breed2', None),
                    employed1=payload.get('employed1', None),
                    employed2=payload.get('employed2', None),
                    spending1=payload.get('spending1', None),
                    spending2=payload.get('spending2', None),
                    ordinaryspending1=payload.get('ordinaryspending1', None),
                    ordinaryspending2=payload.get('ordinaryspending2', None),
                    agriculturalland1=payload.get('agriculturalland1', None),
                    agriculturalland2=payload.get('agriculturalland2', None),
                    bigpets1=payload.get('bigpets1', None),
                    bigpets2=payload.get('bigpets2', None),
                    average1=payload.get('average1', None),
                    average2=payload.get('average2', None),
                    smallpets1=payload.get('smallpets1', None),
                    smallpets2=payload.get('smallpets2', None),
                    fishpond1=payload.get('fishpond1', None),
                    fishpond2=payload.get('fishpond2', None),
                    agriculturaltools1=payload.get('agriculturaltools1', None),
                    agriculturaltools2=payload.get('agriculturaltools2', None),
                    machines1=payload.get('machines1', None),
                    machines2=payload.get('machines2', None),
                    device1=payload.get('device1', None),
                    device2=payload.get('device2', None),
                    home1=payload.get('home1', None),
                    home2=payload.get('home2', None),
                    belongings1=payload.get('belongings1', None),
                    belongings2=payload.get('belongings2', None),
                    smallbelongings1=payload.get('smallbelongings1', None),
                    smallbelongings2=payload.get('smallbelongings2', None),
                    phone1=payload.get('phone1', None),
                    phone2=payload.get('phone2', None),
                    nonagricultural1=payload.get('nonagricultural1', None),
                    nonagricultural2=payload.get('nonagricultural2', None),
                    # cc
                    vehicle1=payload.get('vehicle1', None),
                    vehicle2=payload.get('vehicle2', None),
                    nongovernmental1=payload.get('nongovernmental1', None),
                    nongovernmental2=payload.get('nongovernmental2', None),
                    official1=payload.get('official1', None),
                    official2=payload.get('official2', None),
                    friend1=payload.get('friend1', None),
                    friend2=payload.get('friend2', None),
                    spendingfamily=payload.get('spendingfamily', None),
                    trade1=payload.get('trade1', None),
                    trade2=payload.get('trade2', None),
                    forestry1=payload.get('forestry1', None),
                    forestry2=payload.get('forestry2', None),
                    finance1=payload.get('finance1', None),
                    finance2=payload.get('finance2', None),
                    insurance1=payload.get('insurance1', None),
                    insurance2=payload.get('insurance2', None),
                    business1=payload.get('business1', None),
                    business2=payload.get('business2', None),
                    charity1=payload.get('charity1', None),
                    charity2=payload.get('charity2', None),
                    religion1=payload.get('religion1', None),
                    religion2=payload.get('religion2', None),
                    work=payload.get('work', None),
                    workof=payload.get('workof', None),
                )
                survey_51.save()

        except Exception as e:
            _logger.error(e)
            return HttpResponse()
        return render(request, 'homepage/submit.html')


class ContactSubmit(View):
    def post(self, request):
        if request.method == "POST":
            contact = Contact()
            name = request.POST.get('name')
            email = request.POST.get('email')
            phone = request.POST.get('phone')
            message = request.POST.get('message')
            contact.name = name
            contact.email = email
            contact.phone = phone
            contact.message = message
            contact.save()
            return render(request, 'homepage/ct_submit.html')
        return HttpResponse()
        # return render(request, 'homepage/contact.html')
