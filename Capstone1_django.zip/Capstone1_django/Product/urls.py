from django.urls import path
from .views import HomeView, ContactView, FormView, ResultView, SubmitView, ContactSubmit, DashBoardView, LoginView, \
    LoadDataView, DescribeDataView, ComputingFieldsView, IndependentVarView, ComputingChartsView, IndependentChartsView, \
    LogoutView, ResultChartsView
urlpatterns = [
    path('', HomeView.as_view(), name='index'),
    path('contact/', ContactView.as_view(), name='contact'),
    path('form/', FormView.as_view(), name='form'),
    path('result/', ResultView.as_view(), name='result'),
    path('submit/', SubmitView.as_view(), name='submit'),
    path('ct_submit/', ContactSubmit.as_view(), name='ct_submit'),
    path('login-views/', LoginView.as_view(), name='login-views'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('dash-board/', DashBoardView.as_view(), name='dash-board'),
    path('load-data/', LoadDataView.as_view(), name='load-data'),
    path('describe-data/', DescribeDataView.as_view(), name='describe-data'),
    path('computing-fields/', ComputingFieldsView.as_view(), name='computing-fields'),
    path('independent-var/', IndependentVarView.as_view(), name='independent-var'),
    # ---------------
    path('computing-fields/<str:namechart>/', ComputingChartsView.as_view(), name='computing-chart'),
    path('independent-var/charts/', IndependentChartsView.as_view(), name='view_chart'),
    path('result-chart/<str:namechart>/', ResultChartsView.as_view(), name='result-chart'),
]