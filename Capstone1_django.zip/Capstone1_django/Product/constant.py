# coding=utf-8
import logging

__author__ = 'NamNP'
_logger = logging.getLogger(__name__)

EDUCATION = (
    ("not_study", "Chưa đi học"),
    ("primary_school", "Tiểu học"),
    ("junior_high_school", "THCS"),
    ("high_school", "THPT"),
    ("college", "Cao Đẳng"),
    ("university", "Đại học"),
    ("after_university", "Sau đại học")
)

EDUCATION_MAPPING = (
    ("not_study", 1),
    ("primary_school", 2),
    ("junior_high_school", 3),
    ("high_school", 4),
    ("college", 5),
    ("university", 6),
    ("after_university", 7)
)

AREA = (
    ("plain", "Đồng bằng"),
    ("coastal", "Ven biển"),
    ("midland", "Trung du"),
    ("mountain_island", "Miền núi-hải đảo")
)

GENDER = (
    ("0", "Nam"),
    ("1", "Nữ"),
    ("2", "Khác")
)

NATION = (
    ("nation", "Dân tộc Kinh"),
    ("others", "Dân tộc Khác")
)

AGE = (
    ("18-24", "18-24 tuổi"),
    ("25-30", "25-30 tuổi"),
    ("31-36", "31-36 tuổi"),
    ("37-42", "37-42 tuổi"),
    ("43-50", "43-50 tuổi")
)

CHILDREN = (
    ("not_child", "Chưa có con"),
    ("one_child", "1 con"),
    ("two_children", "2 con"),
    ("three_children", "3 con"),
    ("four_children", "4 con"),
    ("five_children", "5 con"),
    ("more_than_5", "Nhiều hơn")
)
EDUCATIONCHILDREN = (
    ("not_children", "Chưa có con"),
    ("not_study", "Chưa đi học"),
    ("primary_school", "Tiểu học"),
    ("junior_high_school", "THCS"),
    ("high_school", "THPT"),
    ("college", "Cao Đẳng"),
    ("university", "Đại học"),
    ("after_university", "Sau đại học")
)

DISTANCE = (
    ("0-1", "Khoảng 1 km"),
    ("1-2", "Khoảng từ 1-2 km"),
    ("2-3", "Khoảng từ 2-3 km"),
    ("3-4", "Khoảng từ 3-4 km"),
    ("4-5", "Khoảng từ 4-5 km"),
    ("5-7", "Khoảng từ 5-7 km"),
    ("7", "Nhiều hơn 7 km")
)

PEOPLE = (
    ("1", "1 nhân khẩu"),
    ("2", "2 nhân khẩu"),
    ("3", "3 nhân khẩu"),
    ("4", "4 nhân khẩu"),
    ("5", "5 nhân khẩu"),
    ("6", "6 nhân khẩu"),
    ("7", "Nhiều hơn 6 nhân khẩu")
)

INCOME = (
    ("0-3", "Dưới 3 triệu"),
    ("3-5", "Từ 3 đến 5 triệu"),
    ("5-7", "Từ 5 đến 7 triệu"),
    ("7-10", "Từ 7 đến 10 triệu"),
    ("more_10", "Trên 10 triệu")
)

# Tgsx Cay luong thuc
DECISION = (
    ("NoDecision", "Không có quyền ra quyết định"),
    ("NotFamily", "Cùng với một người không ở trong gia đình"),
    ("WithFamily", "Cùng với một thành viên trong gia đình"),
    ("HusbandAndWife", "Vợ chồng cùng ra quyết định"),
    ("AloneDecisions", "Tự mình ra quyết định"),
)

CONFIDENCE = (
    ("VeryUnconfident", "Rất không tự tin"),
    ("NotConfident", "Không tự tin"),
    ("Normal", "Bình thường"),
    ("PrettyConfident", "Khá tự tin"),
    ("VeryConfident", "Rất tự tin")
)
# AGRICULTURALLAND đất nôg nghiệp
OWN = (
    ("NoOwnership", "Không có quyền sở hữu"),
    ("NotFamily", "Sở hữu với người không ở trong gia đình"),
    ("Family", "Sở hữu với một thành viên trong gia đình"),
    ("Co-owningHusbandWife", "Vợ chồng cùng sở hữu"),
    ("OwnASmart", "Sở hữu một minh")
)

LoanAmount = (
    ("AbsolutelyNotLoanable", "Hoàn toàn không vay được"),
    ("NotCanBorrow", "Không chắc là vay được"),
    ("CanBorrowALittle", "Có thể vay được một ít"),
    ("Borrowable", "Vay được"),
    ("DefinitelyLoanable", "Chắc chắn vay được")
)

SelectDecide = (
    ("NoDecision", "Không có quyền ra quyết định"),
    ("NotFamily", "Quyết định với người không ở trong gia đình"),
    ("WithFamily", "Quyết định với một thành viên trong gia đình"),
    ("HusbandAndWife", "Vợ chồng cùng ra quyết định"),
    ("AloneDecisions", "Tự mình ra quyết định")
)
# tgxh
Join = (
    ("NotParticipating", "Chắc chắc không tham gia"),
    ("Consider", "Cân nhắc khi có điều kiện"),
    ("Conditions", "Muốn tham gia nhưng không có điều kiện"),
    ("JoinWhenInvited", "Tham gia khi có lời mời"),
    ("Joined", "Đã tham gia")
)

POSITIVITY = (
    ("VeryNotPositive", "Chưa từng tham gia"),
    ("VeryNotPositive", "Rất không tích cực"),
    ("PrettyPositive", "Khá tích cực"),
    ("Normal", "Bình thường"),
    ("Positive", "Tích cực"),
    ("VeryPositive", "Rất tích cực")
)
WORK = (
    ("time", "Dưới 1 giờ"),
    ("1-3", "Từ 1 đến 3 giờ"),
    ("3-5", "Từ 3 đến 5 giờ"),
    ("8-8", "Từ 5 đến 8 giờ"),
    ("8", "Trên 8 giờ")
)

WORKOF = (
    ("time", "Dưới 1 giờ"),
    ("1-3", "Từ 1 đến 3 giờ"),
    ("3-5", "Từ 3 đến 5 giờ"),
    ("8-8", "Từ 5 đến 8 giờ"),
    ("8", "Trên 8 giờ")
)

INDEX = [
    'Loai địa bàn'
    'Giới tính'
    'Dân tộc'
    'Tuổi của người được hỏi'
    'Học vấn cao nhất của người được hỏi'
    'Học vấn cao nhất của con'
    'Khoảng cách đến đô thị gần nhất'
    'Tổng số nhân khẩu trong hộ'
    'Tổng thu nhập hộ gia đình/tháng'
    'Quyết định trồng cây lương thực'
    'Mức độ tự tin trồng cây lương thực'
    'Quyết định trồng cây thương mại'
    'Mức độ tự tin trồng cây thương mại'
    'Quyết định về hoạt động chăn nuôi'
    'Mức độ tự tin về hoạt động chăn nuôi'
    'Quyết định về làm thuê được trả lương'
    'Mức độ tự tin về làm thuê được trả lương'
    'Quyết định về hoạt động chi tiêu lớn'
    'Mức độ tự tin về hoạt động chi tiêu lớn'
    'Quyết định về hoạt động chi tiêu thông thường'
    'Mức độ tự tin về hoạt động chi tiêu thông thường'
    'Quyền sở hữu tài sản đất nông nghiệp'
    'Tài sản ĐNN thực hiện cùng với ai?'
    'Quyền sở hữu tài sản vật nuôi lớn'
    'Tài sản VNL thực hiện cùng với ai?'
    'Quyền sở hữu tài sản vật nuôi trung bình'
    'Tài sản VNTB thực hiện cùng với ai?'
    'Quyền sở hữu tài sản vật nuôi nhỏ'
    'Tài sản VNN thực hiện cùng với ai?'
    'Quyền sở hữu tài sản ao nuôi cá'
    'Tài sản ANC thực hiện cùng với ai?'
    'Quyền sở hữu tài sản dụng cụ nông nghiệp'
    'Tài sản DCNN thực hiện cùng với ai?'
    'Quyền sở hữu tài sản máy móc nông nghiệp'
    'Tài sản MMNN thực hiện cùng với ai?'
    'Quyền sở hữu tài sản thiết bị phi nông'
    'Tài sản TBPNN thực hiện cùng với ai?'
    'Quyền sở hữu tài sản nhà ở'
    'Tài sản nhà ở thực hiện cùng với ai?'
    'Quyền sở hữu tài sản đồ dùng lâu bền loại lớn'
    'Tài sản ĐDLL thực hiện cùng với ai?'
    'Quyền sở hữu tài sản đồ dùng lâu bền loại nhỏ'
    'Tài sản ĐDLN thực hiện cùng với ai?'
    'Quyền sở hữu tài sản thiết bị điện thoại'
    'Tài sản ĐT thực hiện cùng với ai?'
    'Quyền sở hữu tài sản đất phi nông nghiệp'
    'Tài sản ĐPNN thực hiện cùng với ai?'
    'Quyền sở hữu tài sản phương tiện giao thông'
    'Tài sản PTGT thực hiện cùng với ai?'
    'Quyền vay mượn từ các tổ chức phi chính phủ'
    'Quyền quyết định vay từ các tổ chức phi chính phủ'
    'Quyền vay mượn từ các tổ chức tín dụng chính thức'
    'Quyền quyết định vay từ các tổ chức tín dụng chính thức'
    'Quyền vay mượn từ bạn bè hoặc họ hàng, người thân'
    'Quyền quyết định vay từ bạn bè hoặc họ hàng, người thân'
    'Quyết định chi tiêu hộ gia đình được thực hiện'
    'Tham gia xã hội về các tổ chức nông nghiệp'
    'Tham gia tích cực về các tổ chức nông nghiệp'
    'Tham gia xã hội về các tổ chức lâm nghiệp'
    'Tham gia tích cực về các tổ chức lâm nghiệp'
    'Tham gia xã hội về các tổ chức tín dụng'
    'Tham gia tích cực về các tổ chức tín dụng'
    'Tham gia xã hội về các tổ chức hỗ trợ'
    'Tham gia tích cực về các tổ chức hỗ trợ'
    'Tham gia xã hội về các hiệp hội thương mại'
    'Tham gia tích cực về các hiệp hội thương mại'
    'Tham gia xã hội về hỗ trợ cộng đồng'
    'Tham gia tích cực về hỗ trợ cộng đồng'
    'Tham gia xã hội về các tổ chức tôn giáo'
    'Tham gia tích cực về các tổ chức tôn giáo'
    'Khoảng thời gian làm việc trong ngày'
    'Khoảng thời gian nghỉ ngơi trong ngày'
]
