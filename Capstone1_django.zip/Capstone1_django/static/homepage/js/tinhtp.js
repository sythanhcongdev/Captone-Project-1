//tinh-tp
$.getJSON('https://provinces.open-api.vn/api/', function (data) {
    console.log(data);
    $select = $('#id-city');
    for (let i in data) {
        $select.append(`<option value="${data[i].code}">${data[i].name}</option>`);
//        them cai name --
    }
});
//quan-huyen
var url_quan = 'https://provinces.open-api.vn/api/p/'
$('#id-city').on('change', function () {
    let $districtSelect = $('#id-district');
    $districtSelect.find('option').remove().end().append('<option value="">- Chọn quận/huyện -</option>').val('');
    let $wardSelect = $('#id-ward');
    $wardSelect.find('option').remove().end().append('<option value="">- Chọn phường/xã -</option>').val('');
    let _url_quanhuyen = url_quan + this.value + "?depth=2";
    $.ajax({
        url: _url_quanhuyen, success: function (result) {
            for (let i in result.districts) {
                $districtSelect.append(`<option value="${result.districts[i].code}">${result.districts[i].name}</option>`);
            }
        }
    });
});

//Xa-Phuong
var url_phuongxa = 'https://provinces.open-api.vn/api/d/'
$('#id-district').on('change', function () {
    let $wardSelect = $('#id-ward');
    $wardSelect.find('option').remove().end().append('<option value="">- Chọn phường/xã -</option>').val('');
    let _url_phuongxa = url_phuongxa + this.value + "?depth=2";
    $.ajax({
        url: _url_phuongxa, success: function (result) {
            for (let i in result.wards) {
                $wardSelect.append(`<option value="${result.wards[i].code}">${result.wards[i].name}</option>`);
            }
        }
    });
});
////quan-huyen
//var url_quan = 'https://provinces.open-api.vn/api/p/'
//$('#id-city').on('change', function() {
//    let _url_quanhuyen = url_quan + this.value + "?depth=2";
//    $.ajax({url: _url_quanhuyen, success: function(result){
//        $select = $('#id-district');
//        for (let i in result.districts) {
//            $select.append(`<option value="${result.districts[i].code}">${result.districts[i].name}</option>`);
//        }
//    }});
//});
//
////Xa-Phuong
//var url_phuongxa = 'https://provinces.open-api.vn/api/d/'
//$('#id-district').on('change', function() {
//    let _url_phuongxa = url_phuongxa + this.value + "?depth=2";
//    $.ajax({url: _url_phuongxa, success: function(result){
//        $select = $('#id-ward');
//        for (let i in result.wards) {
//            $select.append(`<option value="${result.wards[i].code}">${result.wards[i].name}</option>`);
//        }
//    }});
//});
